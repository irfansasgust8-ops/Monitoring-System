[CmdletBinding()]
param(
  [string]$AdminHost = "127.0.0.1",
  [ValidateRange(1, 65535)]
  [int]$AdminPort = 5432,
  [ValidatePattern('^[A-Za-z_][A-Za-z0-9_]*$')]
  [string]$AdminUser = "postgres",
  [ValidatePattern('^[A-Za-z_][A-Za-z0-9_]*$')]
  [string]$ApplicationRole = "monitoring_app",
  [ValidatePattern('^[A-Za-z_][A-Za-z0-9_]*$')]
  [string]$ApplicationDatabase = "monitoring_system",
  [ValidatePattern('^[A-Za-z_][A-Za-z0-9_]*$')]
  [string]$TestDatabase = "monitoring_system_test",
  [Security.SecureString]$AdminPassword,
  [Security.SecureString]$ApplicationPassword
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Resolve-PsqlPath {
  $command = Get-Command "psql.exe" -ErrorAction SilentlyContinue
  if ($null -ne $command) {
    return $command.Source
  }

  $postgresRoot = Join-Path $env:ProgramFiles "PostgreSQL"
  if (Test-Path -LiteralPath $postgresRoot) {
    $installations = Get-ChildItem -LiteralPath $postgresRoot -Directory |
      Where-Object { $_.Name -match '^\d+$' } |
      Sort-Object { [int]$_.Name } -Descending

    foreach ($installation in $installations) {
      $candidate = Join-Path $installation.FullName "bin\psql.exe"
      if (Test-Path -LiteralPath $candidate -PathType Leaf) {
        return $candidate
      }
    }
  }

  throw "psql.exe was not found. Install the PostgreSQL 18 command-line tools."
}

function ConvertTo-PlainText([Security.SecureString]$Value) {
  $pointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($Value)
  try {
    return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($pointer)
  }
  finally {
    [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($pointer)
  }
}

function Read-Secret([string]$Prompt, [Security.SecureString]$Provided, [string]$EnvironmentName) {
  $environmentValue = [Environment]::GetEnvironmentVariable($EnvironmentName)
  if (-not [string]::IsNullOrWhiteSpace($environmentValue)) {
    return $environmentValue
  }

  if ($null -ne $Provided) {
    return ConvertTo-PlainText $Provided
  }

  return ConvertTo-PlainText (Read-Host $Prompt -AsSecureString)
}

$psqlPath = Resolve-PsqlPath
$adminPlainText = Read-Secret "PostgreSQL administrator password" $AdminPassword "MONITORING_POSTGRES_ADMIN_PASSWORD"
$applicationPlainText = Read-Secret "Password for application role '$ApplicationRole'" $ApplicationPassword "MONITORING_DATABASE_PASSWORD"

if ([string]::IsNullOrWhiteSpace($adminPlainText) -or [string]::IsNullOrWhiteSpace($applicationPlainText)) {
  throw "Administrator and application passwords must not be empty."
}

$previousPgPassword = [Environment]::GetEnvironmentVariable("PGPASSWORD")
$previousApplicationPassword = [Environment]::GetEnvironmentVariable("MONITORING_DATABASE_PASSWORD")

try {
  $env:PGPASSWORD = $adminPlainText
  $env:MONITORING_DATABASE_PASSWORD = $applicationPlainText

  $roleSql = @"
\set ON_ERROR_STOP on
\getenv application_password MONITORING_DATABASE_PASSWORD
SELECT format('CREATE ROLE %I LOGIN PASSWORD %L', '$ApplicationRole', :'application_password')
WHERE NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = '$ApplicationRole') \gexec
SELECT format('ALTER ROLE %I WITH LOGIN PASSWORD %L', '$ApplicationRole', :'application_password') \gexec
"@

  $roleSql | & $psqlPath --host $AdminHost --port $AdminPort --username $AdminUser --dbname postgres --no-psqlrc --quiet
  if ($LASTEXITCODE -ne 0) {
    throw "Failed to create or update the PostgreSQL application role."
  }

  foreach ($databaseName in @($ApplicationDatabase, $TestDatabase)) {
    $databaseSql = @"
\set ON_ERROR_STOP on
SELECT format('CREATE DATABASE %I OWNER %I', '$databaseName', '$ApplicationRole')
WHERE NOT EXISTS (SELECT 1 FROM pg_database WHERE datname = '$databaseName') \gexec
ALTER DATABASE $databaseName OWNER TO $ApplicationRole;
"@

    $databaseSql | & $psqlPath --host $AdminHost --port $AdminPort --username $AdminUser --dbname postgres --no-psqlrc --quiet
    if ($LASTEXITCODE -ne 0) {
      throw "Failed to initialize PostgreSQL database '$databaseName'."
    }
  }

  Write-Output "PostgreSQL databases '$ApplicationDatabase' and '$TestDatabase' are ready for role '$ApplicationRole'."
  Write-Output "Store the application connection URLs in .env; no credentials were written by this script."
}
finally {
  if ($null -eq $previousPgPassword) {
    Remove-Item Env:PGPASSWORD -ErrorAction SilentlyContinue
  }
  else {
    $env:PGPASSWORD = $previousPgPassword
  }

  if ($null -eq $previousApplicationPassword) {
    Remove-Item Env:MONITORING_DATABASE_PASSWORD -ErrorAction SilentlyContinue
  }
  else {
    $env:MONITORING_DATABASE_PASSWORD = $previousApplicationPassword
  }

  $adminPlainText = $null
  $applicationPlainText = $null
}
