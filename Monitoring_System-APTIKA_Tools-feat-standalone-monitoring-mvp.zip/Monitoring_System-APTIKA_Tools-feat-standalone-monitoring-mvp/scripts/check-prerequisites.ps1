[CmdletBinding()]
param()

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Resolve-PsqlPath {
  $command = Get-Command "psql.exe" -ErrorAction SilentlyContinue
  if ($null -ne $command) {
    return $command.Source
  }

  $postgresRoot = Join-Path $env:ProgramFiles "PostgreSQL"
  if (Test-Path -LiteralPath $postgresRoot) {
    $installations = Get-ChildItem -LiteralPath $postgresRoot -Directory |
      Where-Object { $_.Name -match '^\d+$' } |
      Sort-Object { [int]$_.Name } -Descending

    foreach ($installation in $installations) {
      $candidate = Join-Path $installation.FullName "bin\psql.exe"
      if (Test-Path -LiteralPath $candidate -PathType Leaf) {
        return $candidate
      }
    }
  }

  throw "psql.exe was not found. Install the PostgreSQL 18 command-line tools."
}

$service = Get-Service -Name "postgresql-x64-*" -ErrorAction SilentlyContinue |
  Sort-Object Name -Descending |
  Select-Object -First 1

if ($null -eq $service) {
  throw "No native PostgreSQL Windows service was found."
}

if ($service.Status -ne "Running") {
  throw "PostgreSQL service '$($service.Name)' is not running."
}

$node = Get-Command "node.exe" -ErrorAction SilentlyContinue
if ($null -eq $node) {
  throw "node.exe was not found on PATH."
}

$pnpm = Get-Command "pnpm.cmd" -ErrorAction SilentlyContinue
if ($null -eq $pnpm) {
  throw "pnpm was not found on PATH."
}

$psqlPath = Resolve-PsqlPath
$psqlVersion = (& $psqlPath --version).Trim()
$nodeVersion = (& $node.Source --version).Trim()

Write-Output "PostgreSQL service: $($service.Name) ($($service.Status))"
Write-Output "PostgreSQL CLI: $psqlVersion"
Write-Output "Node.js: $nodeVersion"
Write-Output "pnpm: $($pnpm.Source)"
