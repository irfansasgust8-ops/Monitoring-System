[CmdletBinding()]
param()

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Read-DotEnvValue([string]$Path, [string]$Name) {
  if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
    return $null
  }

  foreach ($line in Get-Content -LiteralPath $Path) {
    $trimmed = $line.Trim()
    if ($trimmed.Length -eq 0 -or $trimmed.StartsWith('#')) {
      continue
    }

    $separator = $trimmed.IndexOf('=')
    if ($separator -le 0) {
      continue
    }

    $candidateName = $trimmed.Substring(0, $separator).Trim()
    if ($candidateName -ne $Name) {
      continue
    }

    $value = $trimmed.Substring($separator + 1).Trim()
    if ($value.Length -ge 2) {
      $first = $value[0]
      $last = $value[$value.Length - 1]
      if (($first -eq '"' -and $last -eq '"') -or ($first -eq "'" -and $last -eq "'")) {
        $value = $value.Substring(1, $value.Length - 2)
      }
    }

    return $value
  }

  return $null
}

$testDatabaseUrl = $env:TEST_DATABASE_URL
if ([string]::IsNullOrWhiteSpace($testDatabaseUrl)) {
  $testDatabaseUrl = Read-DotEnvValue (Join-Path $PSScriptRoot "..\.env") "TEST_DATABASE_URL"
}

if ([string]::IsNullOrWhiteSpace($testDatabaseUrl)) {
  throw "TEST_DATABASE_URL is required in the process environment or root .env file."
}

$databaseUri = [Uri]$testDatabaseUrl
$databaseName = $databaseUri.AbsolutePath.TrimStart('/')
if ($databaseUri.Scheme -notin @('postgres', 'postgresql') -or $databaseName -ne 'monitoring_system_test') {
  throw "Test migrations are restricted to a PostgreSQL database named monitoring_system_test."
}

$previousDatabaseUrl = $env:DATABASE_URL
$previousNodeEnvironment = $env:NODE_ENV
$previousCi = $env:CI
try {
  $env:DATABASE_URL = $testDatabaseUrl
  $env:NODE_ENV = "test"
  $env:CI = "true"
  pnpm --filter @monitoring/database exec prisma migrate deploy
  if ($LASTEXITCODE -ne 0) {
    throw "Prisma test migration failed."
  }
}
finally {
  if ($null -eq $previousDatabaseUrl) {
    Remove-Item Env:DATABASE_URL -ErrorAction SilentlyContinue
  }
  else {
    $env:DATABASE_URL = $previousDatabaseUrl
  }

  if ($null -eq $previousNodeEnvironment) {
    Remove-Item Env:NODE_ENV -ErrorAction SilentlyContinue
  }
  else {
    $env:NODE_ENV = $previousNodeEnvironment
  }

  if ($null -eq $previousCi) {
    Remove-Item Env:CI -ErrorAction SilentlyContinue
  }
  else {
    $env:CI = $previousCi
  }
}
