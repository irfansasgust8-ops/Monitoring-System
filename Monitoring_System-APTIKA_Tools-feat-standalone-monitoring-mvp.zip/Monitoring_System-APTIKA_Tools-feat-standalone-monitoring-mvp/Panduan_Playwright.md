# Panduan Playwright

## Apa Itu Playwright?

Playwright adalah alat yang digunakan untuk menjalankan dan mengendalikan browser secara otomatis.

Secara sederhana, Playwright dapat dibayangkan sebagai robot yang membuka website seperti manusia. Playwright dapat diperintah untuk:

- Membuka website.
- Menunggu halaman selesai ditampilkan.
- Mencari tulisan, tombol, formulir, atau elemen tertentu.
- Mengklik tombol dan mengisi formulir.
- Memeriksa apakah halaman tampil dengan benar.
- Mengambil screenshot ketika terjadi masalah.
- Memberikan hasil pemeriksaan secara otomatis.

Playwright mendukung Chromium, Firefox, dan WebKit. Dalam sistem monitoring ini, browser yang digunakan pada tahap awal adalah Chromium.

Dokumentasi resmi: https://playwright.dev/docs/intro

## Kegunaan Playwright dalam Sistem Monitoring

Pemeriksaan HTTP biasa hanya memastikan bahwa server memberikan respons.

Terkadang website memberikan status HTTP `200`, tetapi halaman yang tampil kosong, gagal dimuat, atau elemen pentingnya tidak muncul.

Playwright membantu memeriksa website dari sisi browser. Contohnya, Playwright dapat memastikan halaman login memiliki:

- Kolom username atau email.
- Kolom password.
- Tombol masuk.
- Judul atau logo aplikasi.
- Elemen penting lain yang sudah ditentukan.

Jika elemen yang diharapkan tidak muncul, hasil pemeriksaan dapat ditandai sebagai `ERROR`. Sistem juga dapat mengambil screenshot agar tim dapat melihat keadaan halaman ketika masalah terjadi.

## Batasan Pemeriksaan Tampilan

Playwright tidak langsung memahami seluruh tampilan seperti manusia.

Sistem harus diberi tahu elemen apa yang ingin diperiksa. Sebagai contoh:

- Tombol login harus tersedia.
- Kolom username harus terlihat.
- Tulisan tertentu harus muncul.
- Halaman tidak boleh kosong.

Playwright dapat mendeteksi elemen yang hilang atau halaman yang gagal ditampilkan. Namun, perubahan kecil seperti warna yang berbeda atau tombol yang bergeser sedikit memerlukan fitur tambahan berupa perbandingan screenshot.

## CAPTCHA dan OTP

Playwright tidak digunakan untuk menembus CAPTCHA atau OTP.

Pada versi awal sistem monitoring, Playwright hanya memastikan halaman login dan elemen pentingnya dapat ditampilkan.

Login secara penuh hanya dapat dikembangkan apabila tersedia:

- Akun khusus untuk pengujian.
- Persetujuan dari pengelola aplikasi.
- Mekanisme CAPTCHA atau OTP khusus untuk kebutuhan monitoring.

## Persyaratan Instalasi

Pastikan Node.js dan npm sudah tersedia.

Jalankan melalui PowerShell:

```powershell
node --version
npm --version
```

Jika kedua perintah menampilkan nomor versi, instalasi dapat dilanjutkan.

## Instalasi pnpm

Project monitoring menggunakan pnpm sebagai pengelola paket.

Pasang pnpm secara global:

```powershell
npm install --global pnpm@11.19.0
```

Perintah tersebut boleh dijalankan dari folder mana saja karena opsi `--global` memasang pnpm pada komputer, bukan ke dalam project.

Periksa hasil instalasinya:

```powershell
pnpm --version
```

Versi yang digunakan oleh project ini adalah `11.19.0`.

## Masuk ke Folder Project

Jalankan:

```powershell
Set-Location 'D:\App\APTIKA\monitoring_system'
```

Pastikan nama foldernya adalah `monitoring_system`.

## Instalasi Playwright

Karena project menggunakan pnpm workspace, Playwright dipasang di root workspace menggunakan opsi `-w`.

```powershell
pnpm add -Dw @playwright/test
```

Keterangan:

- `add` berarti menambahkan paket.
- `-D` berarti paket digunakan untuk pengembangan dan pengujian.
- `-w` berarti paket dipasang di root workspace.

Setelah itu, instal browser Chromium:

```powershell
pnpm exec playwright install chromium
```

Periksa versi Playwright:

```powershell
pnpm exec playwright --version
```

Jika nomor versi muncul, Playwright sudah berhasil dipasang.

## Mencoba Playwright Codegen

Playwright Codegen dapat membuka browser dan merekam aktivitas pengguna.

Jalankan:

```powershell
pnpm exec playwright codegen https://example.com
```

Setelah perintah dijalankan, browser dan Playwright Inspector akan terbuka.

## Contoh Pengujian Sederhana

Buat file bernama:

```text
tests/playwright-example.spec.ts
```

Isi file:

```typescript
import { expect, test } from "@playwright/test";

test("halaman dapat dibuka dan memiliki judul", async ({ page }) => {
  await page.goto("https://example.com");

  await expect(page).toHaveTitle(/Example Domain/);
});
```

Jalankan pengujiannya:

```powershell
pnpm exec playwright test tests/playwright-example.spec.ts
```

Untuk melihat browser ketika pengujian berjalan:

```powershell
pnpm exec playwright test tests/playwright-example.spec.ts --headed
```

## Mengatasi Error Umum

### Error `pnpm is not recognized`

Penyebabnya adalah pnpm belum terpasang atau belum dikenali oleh PowerShell.

Jalankan:

```powershell
npm install --global pnpm@11.19.0
```

Tutup dan buka kembali PowerShell, lalu periksa:

```powershell
pnpm --version
```

### Error `ERR_PNPM_ADDING_TO_ROOT`

Pesan ini muncul karena paket akan dipasang pada root pnpm workspace.

Gunakan opsi `-w`:

```powershell
pnpm add -Dw @playwright/test
```

### Browser Chromium Belum Tersedia

Jika Playwright memberi pesan bahwa browser tidak ditemukan, jalankan:

```powershell
pnpm exec playwright install chromium
```

## Ringkasan

Playwright adalah robot browser yang membantu memeriksa website secara otomatis.

Dalam sistem monitoring, Playwright digunakan untuk:

- Membuka halaman website.
- Memastikan elemen penting muncul.
- Mendeteksi halaman kosong atau gagal ditampilkan.
- Mengukur proses pemuatan halaman.
- Mengambil screenshot ketika terjadi kegagalan.

Urutan instalasi singkat:

```powershell
npm install --global pnpm@11.19.0

Set-Location 'D:\App\APTIKA\monitoring_system'

pnpm add -Dw @playwright/test

pnpm exec playwright install chromium

pnpm exec playwright --version
```
