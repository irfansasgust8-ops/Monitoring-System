# Sistem Monitoring Website — Spesifikasi Desain

Tanggal: 2026-08-23 <br>
Status: Revisi PostgreSQL native telah disetujui, menunggu tinjauan tertulis


## 1. Tujuan

Membangun sistem monitoring website dan aplikasi yang berdiri sendiri untuk sekitar 100 target. Sistem ini mendeteksi ketersediaan, penurunan performa, kegagalan konten, kegagalan rendering browser, kolektor yang tidak lagi memberikan data terbaru, serta periode pemeliharaan. Sistem ini tidak menggunakan Uptime Kuma dan tidak mengubah ataupun men-deploy frontend atau backend Aptika Tools yang sudah ada.

Inventaris target berisi kombinasi yang seimbang antara website publik dan aplikasi yang memiliki halaman login. Sebagian alur login menggunakan CAPTCHA dan OTP. Karena belum tersedia akun otomasi resmi maupun mekanisme otomasi OTP/CAPTCHA yang disetujui, MVP hanya memverifikasi bahwa halaman login dan elemen yang diperlukan berhasil dirender tanpa menjalankan perjalanan sintetis yang terautentikasi.

## 2. Ruang Lingkup

### 2.1 Ruang lingkup MVP

- Autentikasi administrator dan pengguna peninjau yang berdiri sendiri.
- Pengelolaan target yang mencakup nama, URL, organisasi/OPD, status aktif, interval, batas waktu, kata kunci, dan metode monitoring.
- Pemeriksaan HTTP/HTTPS, redirect, DNS, SSL, kata kunci, waktu respons, dan rendering browser.
- Eksekusi terjadwal yang persisten melalui antrean `pg-boss` berbasis PostgreSQL.
- Status saat ini, riwayat pemeriksaan yang hanya dapat ditambahkan, dan riwayat insiden.
- Pembaruan dashboard secara real-time melalui Socket.IO.
- Tangkapan layar kegagalan untuk pemeriksaan browser.
- Status pemeliharaan manual dan tindakan Periksa Sekarang (`Check Now`) yang hanya tersedia bagi administrator.
- Heartbeat kolektor dan status turunan `STALE`.
- Kontrol keamanan untuk kredensial, autentikasi, log, dan pengambilan URL keluar.

### 2.2 Di luar ruang lingkup

- Perubahan atau deployment apa pun terhadap repository Aptika Tools yang sudah ada.
- Penyematan dashboard monitoring ke dalam Aptika Tools.
- Bypass CAPTCHA secara otomatis, intersepsi OTP, atau login tanpa akun dan mekanisme monitoring yang disetujui.
- Notifikasi Telegram/email.
- Ekspor Excel.
- Deployment produksi.
- Monitoring exception kode sumber di dalam aplikasi target.
- Diagnosis bug berbasis AI.

## 3. Batas Sistem

Sistem monitoring merupakan monorepo mandiri yang berakar di `D:\App\APTIKA\monitoring_system`. Posisinya sejajar dengan frontend dan backend Aptika Tools yang sudah ada, bukan sebagai modul di dalam salah satu repository tersebut. Kode sumber Aptika Tools dan deployment Railway yang ada tetap bersifat hanya-baca serta berada di luar batas sistem ini.

```text
D:\App\APTIKA\monitoring_system\
├── apps/
│   ├── web/          Dashboard Next.js
│   ├── api/          REST API Express dan server Socket.IO
│   ├── scheduler/    Penjadwalan target yang jatuh tempo dan pengiriman antrean
│   └── collector/    Worker HTTP dan Playwright
├── packages/
│   ├── database/     Skema Prisma dan client PostgreSQL
│   ├── monitoring/   Kebijakan status dan pemrosesan hasil
│   └── shared/       Skema, tipe, dan konstanta bersama
├── scripts/             Perintah PowerShell untuk penyiapan dan proses lokal
├── storage/
│   └── screenshots/     Tangkapan layar kegagalan privat; tidak pernah dipublikasikan di web
├── tests/
└── docs/
```

### 3.1 Tanggung jawab

#### Aplikasi web

- Menyediakan halaman login, ringkasan dashboard, daftar target, detail target, riwayat pemeriksaan, riwayat insiden, formulir konfigurasi, dan kontrol pemeliharaan.
- Membaca dan mengubah data hanya melalui REST API.
- Berlangganan event status Socket.IO dan memperbarui data dashboard yang tersimpan dalam cache tanpa memuat ulang halaman.
- Tidak pernah menerima kredensial monitoring atau secret milik kolektor.

#### API

- Menangani autentikasi dan otorisasi pengguna, validasi, konfigurasi target, kueri riwayat, kueri insiden, dan otorisasi Periksa Sekarang.
- Menghitung status `STALE` yang ditampilkan berdasarkan timestamp keberhasilan kolektor/pemeriksaan terbaru.
- Menyiarkan transisi status yang telah disimpan dan ringkasan pemeriksaan melalui Socket.IO.
- Tidak menjalankan probe eksternal di dalam handler permintaan HTTP.

#### Penjadwal

- Memilih target aktif yang jadwal pemeriksaan HTTP atau browser berikutnya telah jatuh tempo.
- Mengirim job antrean yang unik dan memajukan waktu jatuh tempo berikutnya secara atomik.
- Menyebarkan waktu eksekusi target untuk mencegah lonjakan lalu lintas yang terjadi secara bersamaan.
- Tidak menjalankan pekerjaan jaringan atau browser secara langsung.

#### Kolektor

- Mengonsumsi job HTTP dan browser dari antrean yang terpisah.
- Menerapkan batas waktu, batas redirect, validasi tujuan yang aman, dan batas konkurensi.
- Menghasilkan fakta yang telah dinormalisasi; kolektor tidak menentukan sendiri label status UI.
- Menyimpan hasil melalui layanan hasil monitoring bersama agar eksekusi terjadwal dan Periksa Sekarang memiliki perilaku yang identik.

#### Paket kebijakan monitoring

- Mengubah hasil pemeriksaan yang telah dinormalisasi beserta status target sebelumnya menjadi status saat ini, nilai penghitung, dan transisi insiden.
- Tetap independen dari detail HTTP, browser, database, dan framework web.
- Mengekspos fungsi deterministik yang sesuai untuk unit test terfokus.

## 4. Pilihan Teknologi

- Frontend: Next.js, TypeScript, dan Tailwind CSS.
- API: Node.js, Express, TypeScript, dan Socket.IO.
- Persistensi: PostgreSQL melalui Prisma.
- Koordinasi antrean dan penjadwalan: `pg-boss` menggunakan server PostgreSQL yang sama dalam skema terkelola tersendiri.
- Otomasi browser: Playwright menggunakan Chromium.
- Penyimpanan tangkapan layar: adapter filesystem lokal privat yang berakar di `storage/screenshots`; antarmukanya dapat diganti dengan penyimpanan S3 di kemudian hari tanpa mengubah perilaku kolektor.
- Client HTTP: client Node.js yang mendukung batas waktu ketat, pemeriksaan redirect, dan metadata respons.
- Runtime pengembangan: service native PostgreSQL 18 Windows yang sudah ada. Proses API, web, penjadwal, dan kolektor berjalan secara independen melalui perintah PowerShell/pnpm.
- Versi dependency dikunci melalui lockfile saat proses scaffolding dilakukan.

## 5. Model Data

### 5.1 `users`

- `id`
- `name`
- `email` (unik)
- `password_hash`
- `role`: `ADMIN` atau `VIEWER`
- `is_active`
- `created_at`, `updated_at`

Hanya administrator yang dapat membuat, mengubah, menonaktifkan, menghapus, mengatur pemeliharaan, atau memeriksa target secara manual. Pengguna dengan peran `VIEWER` hanya memiliki akses baca ke dashboard dan riwayat.

### 5.2 `monitoring_targets`

- `id`
- `name`
- `url`
- `opd_name` (pengelompokan tampilan opsional)
- `enabled`
- `maintenance_mode`
- `http_enabled`
- `browser_enabled`
- `http_interval_seconds` (nilai bawaan 30)
- `browser_interval_seconds` (nilai bawaan 600)
- `timeout_seconds` (nilai bawaan 8)
- `accepted_status_codes` (rentang bawaan 200–399)
- `expected_keyword` (opsional)
- `expected_selector` (assertion browser opsional)
- `slow_threshold_ms` (nilai bawaan 5000)
- `current_status`
- `consecutive_failures`
- `consecutive_content_failures`
- `last_checked_at`
- `last_success_at`
- `next_http_check_at`
- `next_browser_check_at`
- `created_at`, `updated_at`
- `deleted_at` (timestamp soft delete yang dapat bernilai null)

Target baru dimulai dengan status `UNKNOWN`; target tidak pernah ditandai `ONLINE` sebelum pemeriksaan berhasil disimpan.
Penghitung kegagalan ketersediaan dan validasi konten disimpan secara terpisah agar satu jenis kegagalan tidak menghapus atau memperbesar nilai jenis kegagalan lainnya.

### 5.3 `user_sessions`

- `id`
- `user_id`
- `token_hash`
- `csrf_token_hash`
- `expires_at`
- `last_seen_at`
- `revoked_at` (dapat bernilai null)
- `created_at`

Browser hanya menerima token sesi buram di dalam cookie yang aman. Database hanya menyimpan hash token tersebut. Logout dan penonaktifan akun mencabut sesi di sisi server.

### 5.4 `monitoring_checks`

- `id`
- `target_id`
- `check_type`: `HTTP` atau `BROWSER`
- `started_at`, `finished_at`
- `outcome`: `SUCCESS`, `FAILURE`, atau `VALIDATION_FAILURE`
- `http_status` (dapat bernilai null)
- `response_time_ms` (dapat bernilai null)
- `final_url` (dapat bernilai null)
- `redirect_count` (dapat bernilai null)
- `resolved_addresses` (array yang telah disanitasi)
- `keyword_matched` (dapat bernilai null)
- `selector_matched` (dapat bernilai null)
- `ssl_expires_at` (dapat bernilai null)
- `error_category` (dapat bernilai null)
- `error_message` (telah disanitasi dan dapat bernilai null)
- `screenshot_key` (dapat bernilai null)
- `created_at`

Data pemeriksaan mentah disimpan selama 90 hari. Catatan insiden tersedia tanpa batas waktu. File tangkapan layar disimpan selama 30 hari. `screenshot_key` merupakan identifier buram yang dibuat oleh sistem, bukan path absolut atau nama file yang diberikan pengguna.

### 5.5 `monitoring_incidents`

- `id`
- `target_id`
- `kind`: `OFFLINE`, `CONTENT_ERROR`, atau `BROWSER_ERROR`
- `opened_at`
- `closed_at` (dapat bernilai null selama insiden masih terbuka)
- `opening_check_id`
- `closing_check_id` (dapat bernilai null)
- `last_observed_at`
- `created_at`, `updated_at`

Untuk setiap target, hanya boleh ada paling banyak satu insiden terbuka bagi masing-masing jenis insiden. Kegagalan berulang memperbarui insiden yang sudah ada, bukan membuka insiden duplikat.

### 5.6 `collector_heartbeats`

- `collector_id`
- `collector_type`: `HTTP`, `BROWSER`, atau `SCHEDULER`
- `last_seen_at`
- `version`
- `metadata` yang berisi penghitung operasional tanpa secret

### 5.7 `browser_scenarios`

- `id`
- `target_id`
- `start_url`
- `expected_selector`
- `wait_strategy`
- `enabled`
- `created_at`, `updated_at`

MVP hanya mendukung skenario rendering halaman tanpa autentikasi. Field kredensial sengaja tidak disediakan sampai terdapat akun serta mekanisme OTP/CAPTCHA yang disetujui.

### 5.8 Skema antrean

`pg-boss` memiliki tabel antreannya sendiri di dalam skema PostgreSQL khusus. Migrasi aplikasi tidak mengubah tabel internal tersebut. Payload antrean hanya berisi versi, ID target, pemicu, dan waktu terjadwal; URL serta konfigurasi target dibaca dari tabel aplikasi saat worker mulai berjalan.

## 6. Penjadwalan Pemeriksaan dan Konkurensi

### 6.1 Pemeriksaan HTTP

- Interval bawaan: 30 detik.
- Batas waktu bawaan: 8 detik.
- Konkurensi awal worker: 10, dapat dikonfigurasi melalui pengaturan environment.
- Job disebarkan sepanjang interval.
- Hanya satu job HTTP aktif yang diperbolehkan untuk setiap target.
- Job baru tidak dimasukkan ke antrean selama job sebelumnya masih aktif.

### 6.2 Pemeriksaan browser

- Interval bawaan: 10 menit.
- Konkurensi awal worker: 2.
- Satu proses browser yang dapat digunakan kembali boleh membuat context terisolasi; cookie dan penyimpanan tidak pernah dibagikan antar-target.
- Job browser hanya mengambil tangkapan layar ketika terjadi kegagalan.
- Hanya satu job browser aktif yang diperbolehkan untuk setiap target.

### 6.3 Pengendalian beban antrean

- Kunci antrean singleton `pg-boss` mencegah duplikasi job aktif untuk target dan jenis pemeriksaan yang sama.
- Penjadwal mengunci baris target yang jatuh tempo menggunakan `FOR UPDATE SKIP LOCKED` dan memakai adapter PostgreSQL `pg-boss` pada transaksi/koneksi yang sama sehingga pemasukan job ke antrean dan pemajuan waktu jatuh tempo di-commit atau di-roll back secara bersamaan.
- Kedalaman antrean, usia job tertua, jumlah worker aktif, dan jumlah batas waktu yang terlampaui disediakan sebagai metrik operasional.
- Ketika antrean tidak mampu mengimbangi beban, job tetap berada dalam antrean dan API menghasilkan status `STALE`, bukan menyatakan target sebagai `ONLINE`.
- Load test 100 target menentukan konkurensi dan interval produksi akhir; nilai bawaan tidak diubah sampai terdapat bukti yang mendukung penyesuaian.

## 7. Permintaan Keluar yang Aman

Sebelum setiap permintaan awal dan redirect:

- Hanya izinkan skema `http` dan `https`.
- Tolak kredensial yang disematkan dan hostname yang tidak valid.
- Resolve seluruh alamat tujuan.
- Tolak tujuan loopback, private, link-local, multicast, unspecified, dan cloud metadata untuk IPv4 maupun IPv6.
- Lakukan koneksi hanya setelah validasi dan pastikan tujuan yang benar-benar terhubung tetap diperbolehkan.
- Lakukan resolve dan validasi ulang pada setiap redirect untuk menangani DNS rebinding dan bypass berbasis redirect.
- Batasi redirect hingga lima kali.
- Batasi jumlah byte body respons yang digunakan untuk validasi kata kunci.
- Jangan pernah meneruskan cookie kolektor, header otorisasi, atau header internal lintas origin.

Administrator tidak dapat mengesampingkan pembatasan tersebut melalui UI pada MVP.

## 8. Hasil yang Dinormalisasi dan Kebijakan Status

### 8.1 Nilai status

- `UNKNOWN`: belum ada pemeriksaan yang selesai.
- `ONLINE`: pemeriksaan wajib terbaru memenuhi aturan ketersediaan dan validasi.
- `WARNING`: terjadi satu atau dua kegagalan ketersediaan, respons lambat, masa berlaku SSL mendekati habis, atau kegagalan validasi konten yang belum berulang.
- `OFFLINE`: terjadi tiga kegagalan ketersediaan berturut-turut yang disebabkan DNS, koneksi, batas waktu, TLS, atau status akhir HTTP 5xx.
- `ERROR`: kegagalan validasi konten berulang atau assertion elemen browser gagal saat server masih dapat dijangkau.
- `STALE`: tidak ada hasil terbaru dalam waktu dua kali interval yang dikonfigurasi, atau heartbeat kolektor/penjadwal yang diperlukan sudah kedaluwarsa.
- `MAINTENANCE`: status yang dikendalikan administrator untuk menekan notifikasi insiden baru dan alarm visual, sementara pemeriksaan tetap dapat berjalan untuk observasi.

### 8.2 Prioritas status

Urutan prioritas status yang ditampilkan adalah:

`MAINTENANCE` → `STALE` → `OFFLINE` → `ERROR` → `WARNING` → `ONLINE` → `UNKNOWN`.

### 8.3 Aturan transisi

- Pemeriksaan HTTP yang berhasil dengan latensi yang dapat diterima dan kata kunci yang valid menetapkan komponen HTTP menjadi `ONLINE` serta mereset penghitung kegagalan ketersediaan.
- Status akhir HTTP di luar konfigurasi status yang diterima target dihitung sebagai kegagalan ketersediaan.
- Waktu respons yang melebihi ambang target menetapkan status `WARNING` tanpa dihitung sebagai kegagalan ketersediaan.
- Kegagalan ketersediaan pertama atau kedua menetapkan status `WARNING`.
- Kegagalan ketersediaan ketiga secara berturut-turut menetapkan status `OFFLINE` serta membuka atau memperbarui insiden `OFFLINE`.
- Pemeriksaan ketersediaan yang berhasil setelah status `OFFLINE` mengembalikan komponen ketersediaan menjadi `ONLINE` dan menutup insidennya.
- Ketidakcocokan kata kunci pertama menetapkan status `WARNING`; ketidakcocokan ketiga secara berturut-turut menetapkan status `ERROR` dan membuka insiden `CONTENT_ERROR`.
- Validasi kata kunci yang berhasil menutup insiden `CONTENT_ERROR`.
- Kegagalan assertion browser menetapkan status `ERROR` dan membuka atau memperbarui insiden `BROWSER_ERROR`; kegagalan ini tidak menetapkan status `OFFLINE`.
- Assertion browser yang berhasil menutup insiden `BROWSER_ERROR`.
- Masa berlaku SSL yang tersisa kurang dari 30 hari menetapkan status `WARNING`; sertifikat kedaluwarsa diperlakukan sebagai kegagalan ketersediaan ketika validasi TLS mencegah keberhasilan permintaan.
- Status `STALE` diturunkan pada saat pembacaan berdasarkan timestamp dan heartbeat kolektor, sehingga kolektor yang berhenti tidak dapat meninggalkan status `ONLINE` yang seolah-olah masih terbaru.

## 9. Kontrak API

Semua endpoint menggunakan prefiks `/api`.

### 9.1 Autentikasi

- `POST /auth/login`
- `POST /auth/logout`
- `GET /auth/me`
- `GET /auth/csrf`

Autentikasi menggunakan cookie HTTP-only, Secure, dan SameSite. Permintaan yang mengubah status memerlukan token CSRF yang terikat ke sesi dalam sebuah header permintaan, dan permintaan browser berkredensial hanya diterima dari origin web yang telah dikonfigurasi. Respons login tidak pernah mengekspos hash kata sandi atau identifier sesi internal.

### 9.2 Target

- `GET /targets`
- `POST /targets` (`ADMIN`)
- `GET /targets/:id`
- `PUT /targets/:id` (`ADMIN`)
- `DELETE /targets/:id` (`ADMIN`)
- `POST /targets/:id/check-now` (`ADMIN`)
- `POST /targets/:id/maintenance` (`ADMIN`)

`check-now` memasukkan jenis job yang sama dengan yang digunakan penjadwal ke antrean dan mengembalikan `202 Accepted` beserta referensi job publik. Endpoint ini tidak pernah menjalankan probe selama permintaan API berlangsung.

Penghapusan target menggunakan soft delete: penjadwalan langsung dihentikan, sementara riwayat pemeriksaan dan insiden tetap dapat dikueri oleh administrator.

### 9.3 Dashboard dan riwayat

- `GET /dashboard/summary`
- `GET /checks`
- `GET /targets/:id/checks`
- `GET /checks/:id/screenshot`
- `GET /incidents`
- `GET /incidents/:id`
- `GET /collectors/status`

Endpoint daftar mendukung paginasi dan pengurutan stabil dari data terbaru. Status dashboard diturunkan menggunakan aturan prioritas dan `STALE` di atas. File tangkapan layar tetap berada di luar direktori publik web; endpoint tangkapan layar yang terotorisasi memvalidasi sesi dan akses pemeriksaan, tidak menerima path dari permintaan, hanya me-resolve kunci buram yang tersimpan di bawah root tangkapan layar yang dikonfigurasi, menolak traversal atau pelolosan melalui symlink, serta mengalirkan gambar tanpa mengekspos path filesystem.

### 9.4 Event real-time

Socket.IO mengirimkan:

- `monitoring:check-completed`
- `monitoring:status-updated`
- `monitoring:incident-opened`
- `monitoring:incident-closed`
- `monitoring:collector-status`

Event berisi ringkasan target/hasil yang bersifat publik dan tidak pernah memuat secret, HTML mentah, cookie, header, atau alamat internal.

Kolektor memanggil `pg_notify` dengan payload yang telah disanitasi di dalam transaksi hasil yang sama; PostgreSQL hanya mengirimkan notifikasi setelah transaksi tersebut di-commit. API mempertahankan koneksi khusus `LISTEN` dan meneruskan event yang telah divalidasi kepada client Socket.IO yang terautentikasi. Notifikasi PostgreSQL berfungsi sebagai sinyal pembaruan, bukan riwayat persisten: jika API sementara tidak tersedia, data database yang telah disimpan tetap menjadi sumber kebenaran dan client melakukan rekonsiliasi melalui pembacaan REST biasa setelah terhubung kembali.

## 10. Antarmuka Pengguna

### 10.1 Dashboard

- Kartu ringkasan: total, online, warning, offline, error, stale, dan maintenance.
- Indikator pembaruan terbaru dan kesehatan kolektor.
- Filter berdasarkan status, metode, dan OPD.
- Pencarian berdasarkan nama target atau URL publik.
- Insiden terbuka terbaru.

### 10.2 Daftar target

- Nama, URL, OPD, status, status aktif, waktu respons, pemeriksaan terakhir, dan metode monitoring.
- Paginasi, filter, pengurutan stabil, dan tindakan administrator.

### 10.3 Detail target

- Status saat ini dan hasil setiap komponen.
- Konfigurasi HTTP/SSL/browser.
- Pemeriksaan terbaru dan linimasa insiden.
- Riwayat waktu respons.
- Tautan tangkapan layar kegagalan jika tersedia dan pengguna memiliki otorisasi.

### 10.4 Formulir target

- Konfigurasi umum, interval/batas waktu HTTP, kata kunci opsional, toggle browser, dan selector yang diharapkan.
- Kesalahan validasi keamanan URL ditampilkan tanpa mengungkapkan detail jaringan internal.

## 11. Penanganan Kesalahan dan Observabilitas

- Kesalahan dikategorikan sebagai DNS, CONNECT, TIMEOUT, TLS, HTTP_STATUS, REDIRECT, CONTENT, BROWSER, QUEUE, atau INTERNAL.
- Pesan untuk pengguna dibuat ringkas; log terstruktur yang terperinci tetap berada di sisi server.
- Log mencakup correlation ID, target ID, check ID, durasi, dan kategori.
- Log tidak menyertakan body respons, kredensial, cookie, OTP, header otorisasi, atau query string sensitif.
- Kesehatan API, kesehatan PostgreSQL, kedalaman/usia tertua antrean `pg-boss`, heartbeat penjadwal, heartbeat worker, pemeriksaan yang selesai, dan tingkat timeout dapat diamati secara independen.
- Gangguan API atau Socket.IO tidak membuang pemeriksaan yang sudah berada dalam antrean; hasil yang tersimpan dibaca kembali melalui pembacaan dashboard normal ketika client terhubung kembali.

## 12. Strategi Pengujian

### 12.1 Pengujian unit

- Prioritas status dan setiap transisi status.
- Penghitung kegagalan ketersediaan dan kata kunci secara berturut-turut.
- Perilaku pembukaan, pembaruan, dan penutupan insiden.
- Penurunan status `STALE`.
- Kebijakan keamanan URL dan alamat hasil resolve.
- Sanitasi kesalahan dan payload event.

### 12.2 Pengujian integrasi

- Autentikasi dan otorisasi peran.
- CRUD target dan pemasukan Periksa Sekarang ke antrean.
- Persistensi PostgreSQL dan batasan unik untuk insiden terbuka.
- Keunikan job singleton `pg-boss`, percobaan ulang, pemulihan setelah worker berhenti, dan perilaku persistensi antrean.
- Fixture HTTP untuk keberhasilan, respons lambat, timeout, loop redirect, kegagalan DNS, kegagalan TLS, HTTP 500, dan HTTP 200 dengan konten yang salah.
- Pengiriman Socket.IO setelah hasil berhasil disimpan melalui commit.

### 12.3 Pengujian browser dan end-to-end

- Fixture browser dengan selector yang diharapkan tersedia.
- Fixture browser dengan selector yang tidak ditemukan dan tangkapan layar kegagalan yang tersimpan.
- Pemuatan data awal dashboard dan pembaruan status langsung tanpa memuat ulang halaman.
- Hak akses administrator dan `VIEWER`.
- Alur pemeliharaan dan Periksa Sekarang.

### 12.4 Uji kapasitas

- Simulasikan 100 target dengan distribusi representatif berupa target sehat, lambat, dan timeout.
- Pastikan job tidak saling tumpang tindih pada target yang sama.
- Pastikan backlog antrean tidak terus bertambah dalam distribusi pilot yang disepakati.
- Ukur latensi siklus, CPU, memori, kedalaman/usia tertua antrean `pg-boss`, tingkat penulisan PostgreSQL, dan utilisasi worker browser.
- Gunakan hasil tersebut untuk mengubah konkurensi atau interval hanya setelah perilaku MVP tetap berhasil melewati seluruh pengujian.

## 13. Kriteria Penerimaan

- Seratus target dapat dijadwalkan tanpa job yang saling tumpang tindih pada target yang sama.
- Target sehat diperiksa sesuai interval yang dikonfigurasi dalam profil beban pilot.
- Satu target yang lambat atau mengalami timeout tidak menghambat target lainnya.
- HTTP 200 dengan konten wajib yang tidak valid tidak dilaporkan sebagai `ONLINE`.
- Kegagalan ketersediaan berulang mentransisikan status dari `WARNING` menjadi `OFFLINE` dan membuat satu insiden.
- Pemulihan menutup insiden terkait secara deterministik.
- Kegagalan elemen browser dilaporkan sebagai `ERROR`, bukan `OFFLINE`.
- Kolektor atau penjadwal yang berhenti menghasilkan status turunan `STALE`, bukan meninggalkan status `ONLINE` yang seolah-olah masih terbaru.
- Status dashboard diperbarui melalui Socket.IO tanpa pemuatan ulang manual dan tetap benar setelah koneksi ulang/pembacaan ulang.
- Memulai ulang API, penjadwal, atau kolektor tidak menghilangkan konfigurasi target, pekerjaan dalam antrean, riwayat yang tersimpan, atau insiden.
- Hak akses `ADMIN` dan `VIEWER` diterapkan.
- Tujuan yang tidak aman ditolak sebelum koneksi apa pun dilakukan dan setelah setiap redirect.
- Kode sumber dan deployment Aptika Tools yang sudah ada tetap tidak berubah.

## 14. Urutan Pengerjaan

1. Pindahkan monorepo mandiri ke `D:\App\APTIKA\monitoring_system`, konfigurasikan PostgreSQL native, konfigurasi bersama, skrip PowerShell, dan test harness.
2. Skema database, autentikasi, peran, dan CRUD target.
3. Kebijakan monitoring murni dan state machine insiden menggunakan pengembangan berbasis pengujian.
4. Kolektor HTTP, kebijakan pengambilan aman, penjadwal, `pg-boss`, dan Periksa Sekarang.
5. API pembacaan dashboard serta layar target/dashboard Next.js.
6. Event Socket.IO dan pembaruan cache client secara langsung.
7. Worker browser, pemeriksaan selector yang diharapkan, dan tangkapan layar kegagalan.
8. Verifikasi kapasitas/keamanan serta penyesuaian pilot untuk 100 target.

Deployment produksi, integrasi Aptika, kanal notifikasi, ekspor, dan perjalanan browser CAPTCHA/OTP terautentikasi memerlukan desain terpisah yang disetujui setelah MVP selesai diverifikasi.

## 15. Pengoperasian Windows Secara Native

- Database PostgreSQL bernama `monitoring_system` dan `monitoring_system_test`.
- Kode reset test yang bersifat destruktif menolak berjalan kecuali `NODE_ENV=test` dan nama database tepat `monitoring_system_test`.
- Skrip PowerShell untuk penggunaan pertama menerima koneksi PostgreSQL berhak istimewa melalui prompt tersembunyi atau environment variable, membuat/memeriksa database serta peran aplikasi dengan hak akses minimum tanpa mencatat kredensial, kemudian menerapkan migrasi. Skrip lainnya membuat administrator pertama melalui prompt kata sandi tersembunyi, menjalankan setiap proses aplikasi, melaporkan kesehatan sistem, dan menghentikan proses lokal dengan aman.
- Kredensial database dan root absolut tangkapan layar dimuat dari `.env`; `.env` dan isi tangkapan layar diabaikan oleh Git.
- API, web, penjadwal, dan kolektor tetap menjadi proses terpisah meskipun menggunakan satu server PostgreSQL yang sama.
- Dokumentasi startup lokal mencakup pemeriksaan service PostgreSQL, ekspektasi backup, diagnosis worker yang stale, pemeriksaan antrean, dan pemulihan setelah proses dimulai ulang.
