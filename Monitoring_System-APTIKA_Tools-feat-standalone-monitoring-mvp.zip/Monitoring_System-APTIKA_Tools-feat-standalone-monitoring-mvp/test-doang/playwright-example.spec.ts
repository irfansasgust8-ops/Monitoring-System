import { expect, test } from "@playwright/test";

test("website dapat dibuka", async ({ page }) => {
  await page.goto("https://example.com");

  await expect(page).toHaveTitle(/Example Domain/);
  await expect(page.getByRole("heading")).toContainText("Example Domain");
});