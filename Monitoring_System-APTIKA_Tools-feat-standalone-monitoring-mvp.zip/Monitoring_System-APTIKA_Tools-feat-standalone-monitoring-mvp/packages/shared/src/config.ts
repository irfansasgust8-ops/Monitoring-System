import { posix, win32 } from "node:path";

import { z } from "zod";

const positiveIntegerFromString = z.coerce.number<number>().int().positive();
const portFromString = positiveIntegerFromString.max(65_535);
const absolutePath = z
  .string()
  .min(1)
  .refine((value) => win32.isAbsolute(value) || posix.isAbsolute(value));

const configSchema = z.object({
  NODE_ENV: z.enum(["development", "test", "production"]).default("development"),
  DATABASE_URL: z.string().url().startsWith("postgresql://"),
  WEB_ORIGIN: z.string().url().default("http://localhost:3000"),
  API_HOST: z.string().min(1).default("127.0.0.1"),
  API_PORT: portFromString.default(4_000),
  SESSION_COOKIE_NAME: z.string().min(1).default("monitoring_session"),
  SESSION_TTL_SECONDS: positiveIntegerFromString.default(28_800),
  SCREENSHOT_ROOT: absolutePath,
  HTTP_WORKER_CONCURRENCY: positiveIntegerFromString.default(10),
  BROWSER_WORKER_CONCURRENCY: positiveIntegerFromString.default(2)
});

export type AppConfig = Readonly<z.infer<typeof configSchema>>;

export class ConfigurationError extends Error {
  constructor(fields: readonly string[]) {
    super(`Invalid configuration: ${fields.join(", ")}`);
    this.name = "ConfigurationError";
  }
}

export function loadConfig(env: NodeJS.ProcessEnv): AppConfig {
  const result = configSchema.safeParse(env);

  if (!result.success) {
    const fields = [
      ...new Set(
        result.error.issues.map((issue) => issue.path.join(".") || "environment")
      )
    ].sort();

    throw new ConfigurationError(fields);
  }

  return Object.freeze(result.data);
}
