import { describe, expect, it } from "vitest";

import { loadConfig } from "./config.js";

const validEnvironment = {
  NODE_ENV: "test",
  DATABASE_URL: "postgresql://monitoring_app:database-secret@localhost:5432/monitoring_system_test",
  WEB_ORIGIN: "http://localhost:3000",
  API_HOST: "127.0.0.1",
  API_PORT: "4000",
  SESSION_COOKIE_NAME: "monitoring_session",
  SESSION_TTL_SECONDS: "28800",
  SCREENSHOT_ROOT: "D:\\App\\APTIKA\\monitoring_system\\storage\\screenshots",
  HTTP_WORKER_CONCURRENCY: "10",
  BROWSER_WORKER_CONCURRENCY: "2"
} satisfies NodeJS.ProcessEnv;

describe("loadConfig", () => {
  it("returns validated and typed settings", () => {
    // Catches string values leaking past the configuration boundary.
    expect(loadConfig(validEnvironment)).toEqual({
      NODE_ENV: "test",
      DATABASE_URL: validEnvironment.DATABASE_URL,
      WEB_ORIGIN: "http://localhost:3000",
      API_HOST: "127.0.0.1",
      API_PORT: 4000,
      SESSION_COOKIE_NAME: "monitoring_session",
      SESSION_TTL_SECONDS: 28_800,
      SCREENSHOT_ROOT: validEnvironment.SCREENSHOT_ROOT,
      HTTP_WORKER_CONCURRENCY: 10,
      BROWSER_WORKER_CONCURRENCY: 2
    });
  });

  it("rejects a missing database URL", () => {
    // Catches startup with no persistence destination.
    const environment: NodeJS.ProcessEnv = { ...validEnvironment };
    delete environment.DATABASE_URL;

    expect(() => loadConfig(environment)).toThrow(/DATABASE_URL/);
  });

  it("rejects non-numeric worker concurrency", () => {
    // Catches an invalid worker pool size being silently coerced.
    expect(() =>
      loadConfig({ ...validEnvironment, HTTP_WORKER_CONCURRENCY: "many" })
    ).toThrow(/HTTP_WORKER_CONCURRENCY/);
  });

  it("rejects a relative screenshot root", () => {
    // Catches screenshots being written relative to whichever process was started.
    expect(() =>
      loadConfig({ ...validEnvironment, SCREENSHOT_ROOT: "storage/screenshots" })
    ).toThrow(/SCREENSHOT_ROOT/);
  });

  it("does not include secret values in validation errors", () => {
    // Catches credentials being copied into startup logs.
    expect(() =>
      loadConfig({
        ...validEnvironment,
        DATABASE_URL: "not-a-url",
        SCREENSHOT_ROOT: "never-print-this-secret"
      })
    ).toThrowError(
      expect.not.stringContaining("never-print-this-secret")
    );
  });
});
