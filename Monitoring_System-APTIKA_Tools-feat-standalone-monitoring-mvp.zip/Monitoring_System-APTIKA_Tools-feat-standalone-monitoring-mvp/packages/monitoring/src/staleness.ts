import type { DeriveStatusInput, MonitoringStatus } from "./types.js";
import { selectHighestPriorityStatus } from "./status-policy.js";

export function deriveDisplayedStatus(
  input: DeriveStatusInput
): MonitoringStatus {
  const statuses = new Set<MonitoringStatus>([input.persistedStatus]);

  if (isStale(input)) {
    statuses.add("STALE");
  }
  if (input.maintenanceMode) {
    statuses.add("MAINTENANCE");
  }

  return selectHighestPriorityStatus(statuses);
}

function isStale(input: DeriveStatusInput): boolean {
  if (!input.collectorFresh) {
    return true;
  }
  if (!input.lastCheckedAt) {
    return false;
  }

  const ageMs = input.now.getTime() - input.lastCheckedAt.getTime();
  const staleAfterMs = input.intervalSeconds * 2 * 1_000;
  return ageMs > staleAfterMs;
}
