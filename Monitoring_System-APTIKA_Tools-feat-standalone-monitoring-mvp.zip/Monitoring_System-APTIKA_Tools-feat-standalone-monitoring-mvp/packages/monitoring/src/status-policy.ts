import type {
  ApplyCheckResultInput,
  IncidentAction,
  IncidentKind,
  MonitoringStatus,
  MonitoringTransition
} from "./types.js";

const STATUS_PRECEDENCE: readonly MonitoringStatus[] = [
  "MAINTENANCE",
  "STALE",
  "OFFLINE",
  "ERROR",
  "WARNING",
  "ONLINE",
  "UNKNOWN"
];

const THIRTY_DAYS_MS = 30 * 24 * 60 * 60 * 1_000;

export function selectHighestPriorityStatus(
  statuses: ReadonlySet<MonitoringStatus>
): MonitoringStatus {
  return (
    STATUS_PRECEDENCE.find((status) => statuses.has(status)) ?? "UNKNOWN"
  );
}

export function applyCheckResult(
  input: ApplyCheckResultInput
): MonitoringTransition {
  let nextConsecutiveFailures = input.targetState.consecutiveFailures;
  let nextConsecutiveContentFailures =
    input.targetState.consecutiveContentFailures;
  let hasCurrentWarning = false;

  const existingIncidents = new Map(
    input.openIncidents.map((incident) => [incident.kind, incident])
  );
  const activeIncidentKinds = new Set(existingIncidents.keys());
  const incidentActions: IncidentAction[] = [];

  const closeIncident = (kind: IncidentKind): void => {
    const incident = existingIncidents.get(kind);
    if (!incident || !activeIncidentKinds.has(kind)) {
      return;
    }

    incidentActions.push({ action: "CLOSE", incidentId: incident.id });
    activeIncidentKinds.delete(kind);
  };

  const observeIncident = (kind: IncidentKind): void => {
    const incident = existingIncidents.get(kind);
    if (incident) {
      incidentActions.push({ action: "TOUCH", incidentId: incident.id });
    } else {
      incidentActions.push({ action: "OPEN", kind });
    }
    activeIncidentKinds.add(kind);
  };

  if (input.result.checkType === "BROWSER") {
    const browserSucceeded =
      input.result.outcome === "SUCCESS" &&
      input.result.selectorMatched !== false;

    if (browserSucceeded) {
      closeIncident("BROWSER_ERROR");
    } else {
      observeIncident("BROWSER_ERROR");
    }
  } else {
    const isAvailabilityFailure = input.result.outcome === "FAILURE";
    const isContentFailure =
      !isAvailabilityFailure &&
      (input.result.outcome === "VALIDATION_FAILURE" ||
        input.result.keywordMatched === false);

    if (isAvailabilityFailure) {
      nextConsecutiveFailures += 1;

      if (
        nextConsecutiveFailures >= 3 ||
        activeIncidentKinds.has("OFFLINE")
      ) {
        observeIncident("OFFLINE");
      }
    } else if (isContentFailure) {
      nextConsecutiveFailures = 0;
      nextConsecutiveContentFailures += 1;
      closeIncident("OFFLINE");

      if (
        nextConsecutiveContentFailures >= 3 ||
        activeIncidentKinds.has("CONTENT_ERROR")
      ) {
        observeIncident("CONTENT_ERROR");
      }
    } else {
      nextConsecutiveFailures = 0;
      nextConsecutiveContentFailures = 0;
      closeIncident("OFFLINE");
      closeIncident("CONTENT_ERROR");

      hasCurrentWarning =
        isSlowSuccess(input.result.responseTimeMs, input.result.slowThresholdMs) ||
        isCertificateExpiringSoon(input.result.sslExpiresAt, input.now);
    }
  }

  const statusCandidates = new Set<MonitoringStatus>(["ONLINE"]);
  if (
    activeIncidentKinds.has("OFFLINE") ||
    nextConsecutiveFailures >= 3
  ) {
    statusCandidates.add("OFFLINE");
  }
  if (
    activeIncidentKinds.has("CONTENT_ERROR") ||
    activeIncidentKinds.has("BROWSER_ERROR") ||
    nextConsecutiveContentFailures >= 3
  ) {
    statusCandidates.add("ERROR");
  }
  if (
    hasCurrentWarning ||
    nextConsecutiveFailures > 0 ||
    nextConsecutiveContentFailures > 0
  ) {
    statusCandidates.add("WARNING");
  }

  return {
    nextStatus: selectHighestPriorityStatus(statusCandidates),
    nextConsecutiveFailures,
    nextConsecutiveContentFailures,
    incidentActions
  };
}

function isSlowSuccess(
  responseTimeMs: number | null | undefined,
  slowThresholdMs: number | null | undefined
): boolean {
  return (
    responseTimeMs !== null &&
    responseTimeMs !== undefined &&
    slowThresholdMs !== null &&
    slowThresholdMs !== undefined &&
    responseTimeMs > slowThresholdMs
  );
}

function isCertificateExpiringSoon(
  sslExpiresAt: Date | null | undefined,
  now: Date
): boolean {
  if (!sslExpiresAt) {
    return false;
  }

  const remainingMs = sslExpiresAt.getTime() - now.getTime();
  return remainingMs >= 0 && remainingMs <= THIRTY_DAYS_MS;
}
