export {
  applyCheckResult,
  selectHighestPriorityStatus
} from "./status-policy.js";
export { deriveDisplayedStatus } from "./staleness.js";
export type {
  ApplyCheckResultInput,
  CheckOutcome,
  CheckType,
  DeriveStatusInput,
  ErrorCategory,
  IncidentAction,
  IncidentKind,
  MonitoringStatus,
  MonitoringTargetState,
  MonitoringTransition,
  NormalizedCheckResult,
  OpenIncident
} from "./types.js";
