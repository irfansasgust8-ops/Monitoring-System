import { describe, expect, it } from "vitest";

import { deriveDisplayedStatus } from "./staleness.js";
import type { DeriveStatusInput, MonitoringStatus } from "./types.js";

const NOW = new Date("2026-08-24T03:00:00.000Z");

function statusInput(
  overrides: Partial<DeriveStatusInput> = {}
): DeriveStatusInput {
  return {
    persistedStatus: "ONLINE",
    lastCheckedAt: new Date("2026-08-24T02:59:30.000Z"),
    intervalSeconds: 30,
    collectorFresh: true,
    maintenanceMode: false,
    now: NOW,
    ...overrides
  };
}

describe("deriveDisplayedStatus", () => {
  it("derives STALE when the latest check is older than twice the interval", () => {
    // Catches a stopped worker leaving an old ONLINE result visible indefinitely.
    expect(
      deriveDisplayedStatus(
        statusInput({
          lastCheckedAt: new Date("2026-08-24T02:58:59.999Z")
        })
      )
    ).toBe("STALE");
  });

  it("derives STALE when a required collector heartbeat is stale", () => {
    // Catches fresh-looking targets when their required collector has stopped.
    expect(
      deriveDisplayedStatus(statusInput({ collectorFresh: false }))
    ).toBe("STALE");
  });

  it("gives MAINTENANCE precedence over STALE", () => {
    // Catches stale visual alarms leaking through an intentional maintenance period.
    expect(
      deriveDisplayedStatus(
        statusInput({
          collectorFresh: false,
          maintenanceMode: true,
          persistedStatus: "OFFLINE"
        })
      )
    ).toBe("MAINTENANCE");
  });

  it("does not mark the exact two-interval boundary stale", () => {
    // Catches an off-by-one error in the 'older than twice' contract.
    expect(
      deriveDisplayedStatus(
        statusInput({
          lastCheckedAt: new Date("2026-08-24T02:59:00.000Z")
        })
      )
    ).toBe("ONLINE");
  });

  it("keeps a new target UNKNOWN before its first completed check", () => {
    // Catches a never-checked target being mislabeled STALE or ONLINE.
    expect(
      deriveDisplayedStatus(
        statusInput({ persistedStatus: "UNKNOWN", lastCheckedAt: null })
      )
    ).toBe("UNKNOWN");
  });

  it.each([
    "OFFLINE",
    "ERROR",
    "WARNING",
    "ONLINE",
    "UNKNOWN"
  ] as const)("preserves fresh persisted status %s", (persistedStatus) => {
    // Catches read-time derivation changing a fresh underlying component status.
    const lastCheckedAt =
      persistedStatus === "UNKNOWN"
        ? null
        : new Date("2026-08-24T02:59:30.000Z");

    expect(
      deriveDisplayedStatus(
        statusInput({ persistedStatus, lastCheckedAt })
      )
    ).toBe<MonitoringStatus>(persistedStatus);
  });
});
