export type MonitoringStatus =
  | "UNKNOWN"
  | "ONLINE"
  | "WARNING"
  | "OFFLINE"
  | "ERROR"
  | "STALE"
  | "MAINTENANCE";

export type CheckType = "HTTP" | "BROWSER";
export type CheckOutcome = "SUCCESS" | "FAILURE" | "VALIDATION_FAILURE";

export type ErrorCategory =
  | "DNS"
  | "CONNECT"
  | "TIMEOUT"
  | "TLS"
  | "HTTP_STATUS"
  | "REDIRECT"
  | "CONTENT"
  | "BROWSER"
  | "QUEUE"
  | "INTERNAL";

export type IncidentKind = "OFFLINE" | "CONTENT_ERROR" | "BROWSER_ERROR";

export type MonitoringTargetState = {
  currentStatus: MonitoringStatus;
  consecutiveFailures: number;
  consecutiveContentFailures: number;
};

export type NormalizedCheckResult = {
  checkType: CheckType;
  outcome: CheckOutcome;
  errorCategory?: ErrorCategory | null;
  responseTimeMs?: number | null;
  slowThresholdMs?: number | null;
  keywordMatched?: boolean | null;
  selectorMatched?: boolean | null;
  sslExpiresAt?: Date | null;
};

export type OpenIncident = {
  id: string;
  kind: IncidentKind;
};

export type IncidentAction =
  | { action: "OPEN"; kind: IncidentKind }
  | { action: "TOUCH"; incidentId: string }
  | { action: "CLOSE"; incidentId: string };

export type ApplyCheckResultInput = {
  targetState: MonitoringTargetState;
  result: NormalizedCheckResult;
  openIncidents: readonly OpenIncident[];
  now: Date;
};

export type MonitoringTransition = {
  nextStatus: MonitoringStatus;
  nextConsecutiveFailures: number;
  nextConsecutiveContentFailures: number;
  incidentActions: IncidentAction[];
};

export type DeriveStatusInput = {
  persistedStatus: MonitoringStatus;
  lastCheckedAt: Date | null;
  intervalSeconds: number;
  collectorFresh: boolean;
  maintenanceMode: boolean;
  now: Date;
};
