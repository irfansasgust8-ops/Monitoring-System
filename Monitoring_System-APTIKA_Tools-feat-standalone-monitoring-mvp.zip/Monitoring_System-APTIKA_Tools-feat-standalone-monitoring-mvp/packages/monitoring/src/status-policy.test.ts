import { describe, expect, it } from "vitest";

import { applyCheckResult } from "./status-policy.js";
import type {
  MonitoringTargetState,
  NormalizedCheckResult,
  OpenIncident
} from "./types.js";

const NOW = new Date("2026-08-24T03:00:00.000Z");

function targetState(
  overrides: Partial<MonitoringTargetState> = {}
): MonitoringTargetState {
  return {
    currentStatus: "UNKNOWN",
    consecutiveFailures: 0,
    consecutiveContentFailures: 0,
    ...overrides
  };
}

function httpResult(
  overrides: Partial<NormalizedCheckResult> = {}
): NormalizedCheckResult {
  return {
    checkType: "HTTP",
    outcome: "SUCCESS",
    keywordMatched: true,
    ...overrides
  };
}

function transition(
  state: MonitoringTargetState,
  result: NormalizedCheckResult,
  openIncidents: readonly OpenIncident[] = []
) {
  return applyCheckResult({
    targetState: state,
    result,
    openIncidents,
    now: NOW
  });
}

describe("applyCheckResult", () => {
  it("moves UNKNOWN to ONLINE only after required validation succeeds", () => {
    // Catches a target being shown ONLINE before a successful validated check.
    expect(transition(targetState(), httpResult())).toEqual({
      nextStatus: "ONLINE",
      nextConsecutiveFailures: 0,
      nextConsecutiveContentFailures: 0,
      incidentActions: []
    });

    expect(
      transition(
        targetState(),
        httpResult({ outcome: "SUCCESS", keywordMatched: false })
      ).nextStatus
    ).toBe("WARNING");
  });

  it.each([
    { priorFailures: 0, expectedFailures: 1 },
    { priorFailures: 1, expectedFailures: 2 }
  ])(
    "maps availability failure $expectedFailures to WARNING",
    ({ priorFailures, expectedFailures }) => {
      // Catches premature OFFLINE incidents before the third failure.
      expect(
        transition(
          targetState({ consecutiveFailures: priorFailures }),
          httpResult({ outcome: "FAILURE", errorCategory: "TIMEOUT" })
        )
      ).toEqual({
        nextStatus: "WARNING",
        nextConsecutiveFailures: expectedFailures,
        nextConsecutiveContentFailures: 0,
        incidentActions: []
      });
    }
  );

  it("moves the third availability failure to OFFLINE and opens one incident", () => {
    // Catches a missing threshold transition or missing OFFLINE incident action.
    expect(
      transition(
        targetState({
          currentStatus: "WARNING",
          consecutiveFailures: 2
        }),
        httpResult({ outcome: "FAILURE", errorCategory: "HTTP_STATUS" })
      )
    ).toEqual({
      nextStatus: "OFFLINE",
      nextConsecutiveFailures: 3,
      nextConsecutiveContentFailures: 0,
      incidentActions: [{ action: "OPEN", kind: "OFFLINE" }]
    });
  });

  it("touches the existing OFFLINE incident on an additional failure", () => {
    // Catches duplicate OPEN actions for an already-open incident.
    expect(
      transition(
        targetState({
          currentStatus: "OFFLINE",
          consecutiveFailures: 3
        }),
        httpResult({ outcome: "FAILURE", errorCategory: "DNS" }),
        [{ id: "offline-1", kind: "OFFLINE" }]
      )
    ).toEqual({
      nextStatus: "OFFLINE",
      nextConsecutiveFailures: 4,
      nextConsecutiveContentFailures: 0,
      incidentActions: [{ action: "TOUCH", incidentId: "offline-1" }]
    });
  });

  it("recovers to ONLINE, resets counters, and closes HTTP incidents", () => {
    // Catches recovery leaving counters or incidents open after valid HTTP success.
    expect(
      transition(
        targetState({
          currentStatus: "OFFLINE",
          consecutiveFailures: 3,
          consecutiveContentFailures: 3
        }),
        httpResult(),
        [
          { id: "offline-1", kind: "OFFLINE" },
          { id: "content-1", kind: "CONTENT_ERROR" }
        ]
      )
    ).toEqual({
      nextStatus: "ONLINE",
      nextConsecutiveFailures: 0,
      nextConsecutiveContentFailures: 0,
      incidentActions: [
        { action: "CLOSE", incidentId: "offline-1" },
        { action: "CLOSE", incidentId: "content-1" }
      ]
    });
  });

  it("maps a slow success to WARNING while resetting availability failures", () => {
    // Catches latency degradation being counted as an availability failure.
    expect(
      transition(
        targetState({ consecutiveFailures: 2 }),
        httpResult({ responseTimeMs: 5_001, slowThresholdMs: 5_000 })
      )
    ).toEqual({
      nextStatus: "WARNING",
      nextConsecutiveFailures: 0,
      nextConsecutiveContentFailures: 0,
      incidentActions: []
    });
  });

  it.each([
    { priorFailures: 0, expectedFailures: 1, expectedStatus: "WARNING" },
    { priorFailures: 1, expectedFailures: 2, expectedStatus: "WARNING" },
    { priorFailures: 2, expectedFailures: 3, expectedStatus: "ERROR" }
  ] as const)(
    "maps keyword mismatch $expectedFailures to $expectedStatus",
    ({ priorFailures, expectedFailures, expectedStatus }) => {
      // Catches content failures contaminating availability or using its threshold.
      const result = transition(
        targetState({
          consecutiveFailures: 1,
          consecutiveContentFailures: priorFailures
        }),
        httpResult({
          outcome: "VALIDATION_FAILURE",
          errorCategory: "CONTENT",
          keywordMatched: false
        })
      );

      expect(result).toEqual({
        nextStatus: expectedStatus,
        nextConsecutiveFailures: 0,
        nextConsecutiveContentFailures: expectedFailures,
        incidentActions:
          expectedFailures === 3
            ? [{ action: "OPEN", kind: "CONTENT_ERROR" }]
            : []
      });
    }
  );

  it("touches and then closes a CONTENT_ERROR incident deterministically", () => {
    // Catches duplicate content incidents or failure to close on valid recovery.
    const openIncidents = [{ id: "content-1", kind: "CONTENT_ERROR" }] as const;

    expect(
      transition(
        targetState({
          currentStatus: "ERROR",
          consecutiveContentFailures: 3
        }),
        httpResult({
          outcome: "VALIDATION_FAILURE",
          errorCategory: "CONTENT",
          keywordMatched: false
        }),
        openIncidents
      ).incidentActions
    ).toEqual([{ action: "TOUCH", incidentId: "content-1" }]);

    expect(
      transition(
        targetState({
          currentStatus: "ERROR",
          consecutiveContentFailures: 4
        }),
        httpResult(),
        openIncidents
      )
    ).toEqual({
      nextStatus: "ONLINE",
      nextConsecutiveFailures: 0,
      nextConsecutiveContentFailures: 0,
      incidentActions: [{ action: "CLOSE", incidentId: "content-1" }]
    });
  });

  it("maps a browser selector failure to ERROR without creating OFFLINE", () => {
    // Catches browser assertions incrementing availability or opening OFFLINE.
    expect(
      transition(targetState(), {
        checkType: "BROWSER",
        outcome: "VALIDATION_FAILURE",
        errorCategory: "BROWSER",
        selectorMatched: false
      })
    ).toEqual({
      nextStatus: "ERROR",
      nextConsecutiveFailures: 0,
      nextConsecutiveContentFailures: 0,
      incidentActions: [{ action: "OPEN", kind: "BROWSER_ERROR" }]
    });
  });

  it("closes a BROWSER_ERROR on browser success without erasing HTTP warning state", () => {
    // Catches one component's recovery erasing another component's degradation.
    expect(
      transition(
        targetState({
          currentStatus: "ERROR",
          consecutiveFailures: 1
        }),
        {
          checkType: "BROWSER",
          outcome: "SUCCESS",
          selectorMatched: true
        },
        [{ id: "browser-1", kind: "BROWSER_ERROR" }]
      )
    ).toEqual({
      nextStatus: "WARNING",
      nextConsecutiveFailures: 1,
      nextConsecutiveContentFailures: 0,
      incidentActions: [{ action: "CLOSE", incidentId: "browser-1" }]
    });
  });

  it("applies OFFLINE over ERROR over WARNING when issues coexist", () => {
    // Catches a lower-severity latest result hiding a higher-priority open incident.
    const browserFailure = transition(
      targetState({ currentStatus: "OFFLINE", consecutiveFailures: 3 }),
      {
        checkType: "BROWSER",
        outcome: "VALIDATION_FAILURE",
        errorCategory: "BROWSER",
        selectorMatched: false
      },
      [{ id: "offline-1", kind: "OFFLINE" }]
    );

    expect(browserFailure.nextStatus).toBe("OFFLINE");
    expect(browserFailure.incidentActions).toEqual([
      { action: "OPEN", kind: "BROWSER_ERROR" }
    ]);

    const slowWithBrowserError = transition(
      targetState(),
      httpResult({ responseTimeMs: 5_001, slowThresholdMs: 5_000 }),
      [{ id: "browser-1", kind: "BROWSER_ERROR" }]
    );

    expect(slowWithBrowserError.nextStatus).toBe("ERROR");
  });

  it("warns for a certificate expiring within thirty days", () => {
    // Catches an approaching SSL expiry being reported as fully healthy.
    expect(
      transition(
        targetState(),
        httpResult({ sslExpiresAt: new Date("2026-09-20T03:00:00.000Z") })
      ).nextStatus
    ).toBe("WARNING");
  });
});
