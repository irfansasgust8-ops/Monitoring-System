CREATE EXTENSION IF NOT EXISTS "pgcrypto";

CREATE TYPE "UserRole" AS ENUM ('ADMIN', 'VIEWER');
CREATE TYPE "MonitoringStatus" AS ENUM ('UNKNOWN', 'ONLINE', 'WARNING', 'OFFLINE', 'ERROR', 'STALE', 'MAINTENANCE');
CREATE TYPE "CheckType" AS ENUM ('HTTP', 'BROWSER');
CREATE TYPE "CheckOutcome" AS ENUM ('SUCCESS', 'FAILURE', 'VALIDATION_FAILURE');
CREATE TYPE "IncidentKind" AS ENUM ('OFFLINE', 'CONTENT_ERROR', 'BROWSER_ERROR');
CREATE TYPE "CollectorType" AS ENUM ('HTTP', 'BROWSER', 'SCHEDULER');
CREATE TYPE "BrowserWaitStrategy" AS ENUM ('LOAD', 'DOM_CONTENT_LOADED', 'NETWORK_IDLE');
CREATE TYPE "ErrorCategory" AS ENUM ('DNS', 'CONNECT', 'TIMEOUT', 'TLS', 'HTTP_STATUS', 'REDIRECT', 'CONTENT', 'BROWSER', 'QUEUE', 'INTERNAL');

CREATE TABLE "users" (
  "id" UUID NOT NULL DEFAULT gen_random_uuid(),
  "name" VARCHAR(200) NOT NULL,
  "email" VARCHAR(320) NOT NULL,
  "password_hash" VARCHAR(255) NOT NULL,
  "role" "UserRole" NOT NULL,
  "is_active" BOOLEAN NOT NULL DEFAULT true,
  "created_at" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updated_at" TIMESTAMPTZ(3) NOT NULL,
  CONSTRAINT "users_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "user_sessions" (
  "id" UUID NOT NULL DEFAULT gen_random_uuid(),
  "user_id" UUID NOT NULL,
  "token_hash" VARCHAR(64) NOT NULL,
  "csrf_token_hash" VARCHAR(64) NOT NULL,
  "expires_at" TIMESTAMPTZ(3) NOT NULL,
  "last_seen_at" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "revoked_at" TIMESTAMPTZ(3),
  "created_at" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "user_sessions_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "monitoring_targets" (
  "id" UUID NOT NULL DEFAULT gen_random_uuid(),
  "name" VARCHAR(200) NOT NULL,
  "url" TEXT NOT NULL,
  "opd_name" VARCHAR(200),
  "enabled" BOOLEAN NOT NULL DEFAULT true,
  "maintenance_mode" BOOLEAN NOT NULL DEFAULT false,
  "http_enabled" BOOLEAN NOT NULL DEFAULT true,
  "browser_enabled" BOOLEAN NOT NULL DEFAULT false,
  "http_interval_seconds" INTEGER NOT NULL DEFAULT 30,
  "browser_interval_seconds" INTEGER NOT NULL DEFAULT 600,
  "timeout_seconds" INTEGER NOT NULL DEFAULT 8,
  "accepted_status_codes" JSONB NOT NULL DEFAULT '{"ranges":[[200,399]]}',
  "expected_keyword" TEXT,
  "expected_selector" TEXT,
  "slow_threshold_ms" INTEGER NOT NULL DEFAULT 5000,
  "current_status" "MonitoringStatus" NOT NULL DEFAULT 'UNKNOWN',
  "consecutive_failures" INTEGER NOT NULL DEFAULT 0,
  "consecutive_content_failures" INTEGER NOT NULL DEFAULT 0,
  "last_checked_at" TIMESTAMPTZ(3),
  "last_success_at" TIMESTAMPTZ(3),
  "next_http_check_at" TIMESTAMPTZ(3),
  "next_browser_check_at" TIMESTAMPTZ(3),
  "created_at" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updated_at" TIMESTAMPTZ(3) NOT NULL,
  "deleted_at" TIMESTAMPTZ(3),
  CONSTRAINT "monitoring_targets_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "monitoring_checks" (
  "id" UUID NOT NULL DEFAULT gen_random_uuid(),
  "target_id" UUID NOT NULL,
  "check_type" "CheckType" NOT NULL,
  "started_at" TIMESTAMPTZ(3) NOT NULL,
  "finished_at" TIMESTAMPTZ(3) NOT NULL,
  "outcome" "CheckOutcome" NOT NULL,
  "http_status" INTEGER,
  "response_time_ms" INTEGER,
  "final_url" TEXT,
  "redirect_count" INTEGER,
  "resolved_addresses" TEXT[] NOT NULL DEFAULT ARRAY[]::TEXT[],
  "keyword_matched" BOOLEAN,
  "selector_matched" BOOLEAN,
  "ssl_expires_at" TIMESTAMPTZ(3),
  "error_category" "ErrorCategory",
  "error_message" TEXT,
  "screenshot_key" VARCHAR(100),
  "created_at" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "monitoring_checks_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "monitoring_incidents" (
  "id" UUID NOT NULL DEFAULT gen_random_uuid(),
  "target_id" UUID NOT NULL,
  "kind" "IncidentKind" NOT NULL,
  "opened_at" TIMESTAMPTZ(3) NOT NULL,
  "closed_at" TIMESTAMPTZ(3),
  "opening_check_id" UUID NOT NULL,
  "closing_check_id" UUID,
  "last_observed_at" TIMESTAMPTZ(3) NOT NULL,
  "created_at" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updated_at" TIMESTAMPTZ(3) NOT NULL,
  CONSTRAINT "monitoring_incidents_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "collector_heartbeats" (
  "collector_id" VARCHAR(100) NOT NULL,
  "collector_type" "CollectorType" NOT NULL,
  "last_seen_at" TIMESTAMPTZ(3) NOT NULL,
  "version" VARCHAR(50) NOT NULL,
  "metadata" JSONB NOT NULL DEFAULT '{}',
  CONSTRAINT "collector_heartbeats_pkey" PRIMARY KEY ("collector_id")
);

CREATE TABLE "browser_scenarios" (
  "id" UUID NOT NULL DEFAULT gen_random_uuid(),
  "target_id" UUID NOT NULL,
  "start_url" TEXT NOT NULL,
  "expected_selector" TEXT NOT NULL,
  "wait_strategy" "BrowserWaitStrategy" NOT NULL DEFAULT 'LOAD',
  "enabled" BOOLEAN NOT NULL DEFAULT true,
  "created_at" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updated_at" TIMESTAMPTZ(3) NOT NULL,
  CONSTRAINT "browser_scenarios_pkey" PRIMARY KEY ("id")
);

CREATE UNIQUE INDEX "users_email_key" ON "users"("email");
CREATE UNIQUE INDEX "user_sessions_token_hash_key" ON "user_sessions"("token_hash");
CREATE INDEX "user_sessions_user_id_expires_at_idx" ON "user_sessions"("user_id", "expires_at");
CREATE INDEX "user_sessions_expires_at_revoked_at_idx" ON "user_sessions"("expires_at", "revoked_at");
CREATE INDEX "monitoring_targets_enabled_deleted_at_next_http_check_at_idx" ON "monitoring_targets"("enabled", "deleted_at", "next_http_check_at");
CREATE INDEX "monitoring_targets_enabled_deleted_at_next_browser_check_at_idx" ON "monitoring_targets"("enabled", "deleted_at", "next_browser_check_at");
CREATE INDEX "monitoring_targets_current_status_deleted_at_idx" ON "monitoring_targets"("current_status", "deleted_at");
CREATE INDEX "monitoring_checks_target_id_created_at_idx" ON "monitoring_checks"("target_id", "created_at" DESC);
CREATE INDEX "monitoring_checks_created_at_idx" ON "monitoring_checks"("created_at");
CREATE INDEX "monitoring_incidents_target_id_closed_at_opened_at_idx" ON "monitoring_incidents"("target_id", "closed_at", "opened_at" DESC);
CREATE INDEX "monitoring_incidents_opened_at_idx" ON "monitoring_incidents"("opened_at" DESC);
CREATE UNIQUE INDEX "monitoring_incidents_one_open_kind_per_target" ON "monitoring_incidents"("target_id", "kind") WHERE "closed_at" IS NULL;
CREATE INDEX "collector_heartbeats_collector_type_last_seen_at_idx" ON "collector_heartbeats"("collector_type", "last_seen_at");
CREATE UNIQUE INDEX "browser_scenarios_target_id_key" ON "browser_scenarios"("target_id");

ALTER TABLE "user_sessions" ADD CONSTRAINT "user_sessions_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "monitoring_checks" ADD CONSTRAINT "monitoring_checks_target_id_fkey" FOREIGN KEY ("target_id") REFERENCES "monitoring_targets"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "monitoring_incidents" ADD CONSTRAINT "monitoring_incidents_target_id_fkey" FOREIGN KEY ("target_id") REFERENCES "monitoring_targets"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "monitoring_incidents" ADD CONSTRAINT "monitoring_incidents_opening_check_id_fkey" FOREIGN KEY ("opening_check_id") REFERENCES "monitoring_checks"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "monitoring_incidents" ADD CONSTRAINT "monitoring_incidents_closing_check_id_fkey" FOREIGN KEY ("closing_check_id") REFERENCES "monitoring_checks"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "browser_scenarios" ADD CONSTRAINT "browser_scenarios_target_id_fkey" FOREIGN KEY ("target_id") REFERENCES "monitoring_targets"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
