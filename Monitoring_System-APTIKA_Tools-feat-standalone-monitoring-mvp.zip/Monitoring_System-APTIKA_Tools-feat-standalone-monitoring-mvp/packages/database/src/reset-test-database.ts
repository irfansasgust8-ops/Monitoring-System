import type { PrismaClient } from "./generated/prisma/client.js";

const resetStatement = `
TRUNCATE TABLE
  "browser_scenarios",
  "collector_heartbeats",
  "monitoring_incidents",
  "monitoring_checks",
  "user_sessions",
  "monitoring_targets",
  "users"
RESTART IDENTITY CASCADE
`;

export function assertSafeTestDatabaseUrl(
  databaseUrl: string,
  nodeEnvironment: string | undefined = process.env.NODE_ENV
): void {
  if (nodeEnvironment !== "test") {
    throw new Error("Database reset requires NODE_ENV=test");
  }

  let parsed: URL;
  try {
    parsed = new URL(databaseUrl);
  } catch {
    throw new Error("Database reset requires a valid PostgreSQL URL");
  }

  const databaseName = decodeURIComponent(parsed.pathname.replace(/^\//, ""));
  if (databaseName !== "monitoring_system_test") {
    throw new Error(
      "Database reset is restricted to the monitoring_system_test database"
    );
  }
}

export async function resetTestDatabase(
  database: PrismaClient,
  databaseUrl: string
): Promise<void> {
  assertSafeTestDatabaseUrl(databaseUrl);
  await database.$executeRawUnsafe(resetStatement);
}
