import { PrismaPg } from "@prisma/adapter-pg";

import { PrismaClient } from "./generated/prisma/client.js";

let singleton: PrismaClient | undefined;

function assertPostgresqlUrl(databaseUrl: string): void {
  let parsed: URL;
  try {
    parsed = new URL(databaseUrl);
  } catch {
    throw new Error("DATABASE_URL must be a valid PostgreSQL URL");
  }

  if (parsed.protocol !== "postgresql:" && parsed.protocol !== "postgres:") {
    throw new Error("DATABASE_URL must use the postgresql scheme");
  }
}

export function createPrismaClient(databaseUrl: string): PrismaClient {
  assertPostgresqlUrl(databaseUrl);
  return new PrismaClient({ adapter: new PrismaPg(databaseUrl) });
}

export function getPrismaClient(
  environment: NodeJS.ProcessEnv = process.env
): PrismaClient {
  if (singleton) {
    return singleton;
  }

  const databaseUrl = environment.DATABASE_URL;
  if (!databaseUrl) {
    throw new Error("DATABASE_URL is required before opening the database");
  }

  singleton = createPrismaClient(databaseUrl);
  return singleton;
}

export async function disconnectPrismaClient(): Promise<void> {
  if (!singleton) {
    return;
  }

  await singleton.$disconnect();
  singleton = undefined;
}

export type DatabaseClient = PrismaClient;
