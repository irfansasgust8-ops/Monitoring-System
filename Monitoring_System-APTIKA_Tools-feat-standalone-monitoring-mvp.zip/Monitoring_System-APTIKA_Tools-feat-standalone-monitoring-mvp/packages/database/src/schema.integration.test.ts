import { resolve } from "node:path";

import { config as loadEnvironmentFile } from "dotenv";
import { afterAll, beforeAll, describe, expect, it } from "vitest";

import { createPrismaClient } from "./client.js";
import { resetTestDatabase } from "./reset-test-database.js";

loadEnvironmentFile({
  path: resolve(import.meta.dirname, "../../../.env"),
  override: false,
  quiet: true
});

const testDatabaseUrl = process.env.TEST_DATABASE_URL;
const describeWithDatabase = testDatabaseUrl ? describe : describe.skip;

describeWithDatabase("monitoring database schema", () => {
  if (!testDatabaseUrl) {
    return;
  }

  const database = createPrismaClient(testDatabaseUrl);

  beforeAll(async () => {
    await resetTestDatabase(database, testDatabaseUrl);
  });

  afterAll(async () => {
    await resetTestDatabase(database, testDatabaseUrl);
    await database.$disconnect();
  });

  it("starts a new target as UNKNOWN and preserves its history after soft deletion", async () => {
    // Catches an unsafe ONLINE default or a hard-delete cascade erasing audit history.
    const target = await database.monitoringTarget.create({
      data: {
        name: "Public service",
        url: "https://example.test"
      }
    });

    expect(target.currentStatus).toBe("UNKNOWN");

    const check = await database.monitoringCheck.create({
      data: {
        targetId: target.id,
        checkType: "HTTP",
        startedAt: new Date("2026-08-23T08:00:00.000Z"),
        finishedAt: new Date("2026-08-23T08:00:00.100Z"),
        outcome: "SUCCESS"
      }
    });

    await database.monitoringTarget.update({
      where: { id: target.id },
      data: { deletedAt: new Date("2026-08-23T09:00:00.000Z") }
    });

    expect(
      await database.monitoringCheck.findUnique({ where: { id: check.id } })
    ).toMatchObject({ targetId: target.id });
  });

  it("allows only one open incident of a kind per target", async () => {
    // Catches a missing partial unique index that creates duplicate open incidents.
    const target = await database.monitoringTarget.create({
      data: { name: "Incident target", url: "https://incident.example.test" }
    });
    const openingCheck = await database.monitoringCheck.create({
      data: {
        targetId: target.id,
        checkType: "HTTP",
        startedAt: new Date("2026-08-23T10:00:00.000Z"),
        finishedAt: new Date("2026-08-23T10:00:08.000Z"),
        outcome: "FAILURE",
        errorCategory: "TIMEOUT"
      }
    });

    const incident = {
      targetId: target.id,
      kind: "OFFLINE" as const,
      openedAt: new Date("2026-08-23T10:00:08.000Z"),
      lastObservedAt: new Date("2026-08-23T10:00:08.000Z"),
      openingCheckId: openingCheck.id
    };

    await database.monitoringIncident.create({ data: incident });

    await expect(
      database.monitoringIncident.create({ data: incident })
    ).rejects.toThrow();
  });

  it("stores a session token hash instead of the browser token", async () => {
    // Catches plaintext bearer tokens being persisted in the session table.
    const user = await database.user.create({
      data: {
        name: "Administrator",
        email: "admin@example.test",
        passwordHash: "argon2id-test-hash",
        role: "ADMIN"
      }
    });

    const browserToken = "browser-session-token";
    const session = await database.userSession.create({
      data: {
        userId: user.id,
        tokenHash: "06a6cf69f59430e4db001c6f1dff26e62c50f2317e00c15c85d1f091e39d89b1",
        csrfTokenHash: "ae0d74b02f56698e32f265f04f50eaa74f18143a8a6d82bc98b539622d155ffe",
        expiresAt: new Date("2026-08-24T10:00:00.000Z"),
        lastSeenAt: new Date("2026-08-23T10:00:00.000Z")
      }
    });

    expect(session.tokenHash).not.toBe(browserToken);
    expect(session).not.toHaveProperty("token");
  });
});
