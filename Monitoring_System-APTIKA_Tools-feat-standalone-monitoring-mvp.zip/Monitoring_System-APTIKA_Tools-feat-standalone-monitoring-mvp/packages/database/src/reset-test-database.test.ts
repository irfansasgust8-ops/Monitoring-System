import { describe, expect, it } from "vitest";

import { assertSafeTestDatabaseUrl } from "./reset-test-database.js";

describe("assertSafeTestDatabaseUrl", () => {
  it("accepts only monitoring_system_test while NODE_ENV is test", () => {
    // Catches a destructive reset accidentally targeting the development database.
    expect(() =>
      assertSafeTestDatabaseUrl(
        "postgresql://monitoring_app:secret@127.0.0.1:5432/monitoring_system_test",
        "test"
      )
    ).not.toThrow();

    expect(() =>
      assertSafeTestDatabaseUrl(
        "postgresql://monitoring_app:secret@127.0.0.1:5432/monitoring_system",
        "test"
      )
    ).toThrow(/monitoring_system_test/);

    expect(() =>
      assertSafeTestDatabaseUrl(
        "postgresql://monitoring_app:secret@127.0.0.1:5432/monitoring_system_test",
        "development"
      )
    ).toThrow(/NODE_ENV=test/);
  });
});
