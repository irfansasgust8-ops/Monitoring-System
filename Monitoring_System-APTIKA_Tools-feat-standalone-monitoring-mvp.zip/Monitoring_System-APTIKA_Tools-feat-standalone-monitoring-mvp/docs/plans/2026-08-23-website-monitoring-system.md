# Website Monitoring System Implementation Plan

> **For agentic workers:** Use the host's available task-by-task implementation workflow. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a standalone, locally runnable MVP that monitors approximately 100 public and login-page websites without Uptime Kuma or changes to Aptika Tools.

**Architecture:** A pnpm TypeScript monorepo contains an independent Next.js web application, Express API/Socket.IO server, `pg-boss` scheduler, HTTP/Playwright collectors, shared monitoring policy, and Prisma/PostgreSQL persistence. PostgreSQL also owns durable queue coordination and commit-ordered `LISTEN`/`NOTIFY` update signals. Failure screenshots live beneath a private local filesystem root. The API owns configuration and reads; workers perform checks and publish sanitized post-commit events. Existing Aptika Tools repositories and Railway deployment remain outside the project boundary.

**Tech Stack:** Node.js, TypeScript, pnpm workspaces, Next.js, Tailwind CSS, Express, Socket.IO, PostgreSQL 18, Prisma, `pg-boss`, Playwright Chromium, local filesystem storage, Zod, Vitest, Testing Library, and Playwright Test.

## Global Constraints

- Do not modify, copy into, push, or deploy `D:\App\APTIKA\be_aptika` or `D:\App\APTIKA\fe_aptika`.
- Do not access or change the existing Aptika Tools Railway project.
- Keep the new project within `D:\App\APTIKA\monitoring_system`.
- Do not require Docker, Redis, MinIO, or another infrastructure service beyond the existing native PostgreSQL 18 Windows service.
- Do not use Uptime Kuma.
- Do not automate or bypass CAPTCHA/OTP. MVP browser checks stop at validating the login page and configured public element.
- New targets begin `UNKNOWN`; never mark a target ONLINE until a successful check is persisted.
- The API never performs network/browser probes inside request handlers.
- Validate every initial and redirected destination against IPv4/IPv6 SSRF rules before connecting.
- Persist a check before updating state, incidents, or publishing a real-time event.
- Derive STALE from timestamps and heartbeats so a stopped worker cannot leave a falsely current ONLINE result.
- Store no raw response bodies, cookies, passwords, authorization headers, OTP values, or unsafe internal addresses in logs/events.
- Use TDD for every externally visible behavior: observe a focused failing test, implement the minimum, then refactor while green.
- Production deployment, Aptika integration, notifications, exports, authenticated synthetic login, and AI diagnosis remain out of scope.

All paths below are proposed new files except the observed design specification at `docs/specs/2026-08-23-website-monitoring-system-design.md`.

---

### Task 1: Standalone monorepo and local infrastructure

**Files:**
- Create: `package.json`
- Create: `pnpm-workspace.yaml`
- Create: `tsconfig.base.json`
- Create: `.gitignore`
- Create: `.env.example`
- Create: `scripts/check-prerequisites.ps1`
- Create: `scripts/setup-postgres.ps1`
- Create: `storage/screenshots/.gitkeep`
- Create: `packages/shared/package.json`
- Create: `packages/shared/tsconfig.json`
- Create: `packages/shared/src/config.ts`
- Create: `packages/shared/src/config.test.ts`
- Create: `packages/shared/src/index.ts`
- Create: `vitest.workspace.ts`
- Modify: `docs/specs/2026-08-23-website-monitoring-system-design.md` only if implementation discovers a contradiction; document the deviation before code relies on it.

**Interfaces:**
- Consumes: process environment variables documented by `.env.example`.
- Produces: `loadConfig(env: NodeJS.ProcessEnv): AppConfig`; root scripts `dev`, `build`, `test`, `typecheck`, and `lint`; native PostgreSQL prerequisite/setup scripts; a private screenshot root.

- [x] **Step 1: Add the focused failing configuration test**

Create Vitest cases asserting that `loadConfig` returns typed database/session/filesystem settings for valid input, rejects a missing `DATABASE_URL`, rejects a relative screenshot root, rejects a non-numeric worker concurrency, and never includes secrets in the formatted validation error.

- [x] **Step 2: Verify the relevant failure**

Run: `pnpm install && pnpm --filter @monitoring/shared test -- config.test.ts`

Expected: non-zero exit because `packages/shared/src/config.ts` and `loadConfig` do not exist; dependency installation succeeds.

- [x] **Step 3: Implement the minimum foundation**

Use the existing standalone Git repository at `D:\App\APTIKA\monitoring_system`. Define a private pnpm workspace. Add Zod-backed configuration with `NODE_ENV`, `DATABASE_URL`, `WEB_ORIGIN`, `API_HOST`, `API_PORT`, `SESSION_COOKIE_NAME`, `SESSION_TTL_SECONDS`, `SCREENSHOT_ROOT`, `HTTP_WORKER_CONCURRENCY`, and `BROWSER_WORKER_CONCURRENCY`. Provide non-secret local defaults only for host/ports and concurrency; require database credentials and the absolute screenshot root through `.env`.

Add PowerShell scripts that detect the native PostgreSQL 18 Windows service and `psql`, and initialize `monitoring_system` plus `monitoring_system_test` with a least-privilege application role. Privileged and application passwords must come from hidden prompts or environment variables and must never be printed. No Docker Compose, Redis, MinIO, or cloud setup is part of this task.

Root scripts delegate recursively to workspace packages. `.gitignore` excludes `.env`, dependencies, build output, Playwright artifacts, coverage, screenshots, and local volumes.

- [x] **Step 4: Verify the focused pass**

Run: `pnpm --filter @monitoring/shared test -- config.test.ts`

Expected: all configuration cases pass.

- [x] **Step 5: Run the affected integration check**

Run: `powershell -NoProfile -ExecutionPolicy Bypass -File scripts/check-prerequisites.ps1 && pnpm typecheck`

Expected: the native PostgreSQL service and CLI are detected, and TypeScript exits zero.

- [x] **Step 6: Commit the passing deliverable**

```bash
git add package.json pnpm-workspace.yaml tsconfig.base.json .gitignore .env.example scripts storage/screenshots/.gitkeep vitest.workspace.ts packages/shared docs/specs/2026-08-23-website-monitoring-system-design.md docs/plans/2026-08-23-website-monitoring-system.md
git commit -m "chore: scaffold standalone monitoring workspace"
```

### Task 2: PostgreSQL schema and deterministic database test lifecycle

**Files:**
- Create: `packages/database/package.json`
- Create: `packages/database/tsconfig.json`
- Create: `packages/database/prisma/schema.prisma`
- Create: `packages/database/prisma.config.ts`
- Create: `packages/database/prisma/migrations/20260823000000_initial/migration.sql`
- Create: `packages/database/src/client.ts`
- Create: `packages/database/src/reset-test-database.ts`
- Create: `packages/database/src/schema.integration.test.ts`
- Create: `packages/database/src/index.ts`

**Interfaces:**
- Consumes: `AppConfig.DATABASE_URL`.
- Produces: `createPrismaClient(databaseUrl)`, lazy `getPrismaClient()`, Prisma models `User`, `UserSession`, `MonitoringTarget`, `MonitoringCheck`, `MonitoringIncident`, `CollectorHeartbeat`, and `BrowserScenario`; guarded `resetTestDatabase(client, databaseUrl)`.

- [ ] **Step 1: Add the focused failing schema test**

Create an integration test that inserts:

- A new target and asserts `currentStatus === "UNKNOWN"`.
- A check connected to the target.
- One open incident and rejects a second open incident with the same target/kind.
- A soft-deleted target whose checks remain readable.
- A session storing a token hash rather than a plaintext token.

- [ ] **Step 2: Verify the relevant failure**

Run: `pnpm --filter @monitoring/database test -- schema.integration.test.ts`

Expected: non-zero exit because the Prisma schema/client are absent.

- [ ] **Step 3: Implement the minimum schema**

Translate section 5 of the approved design into Prisma enums, models, indexes, foreign keys, and constraints. Implement the one-open-incident-per-target/kind rule with a PostgreSQL partial unique index in the migration. Use `onDelete: Restrict` for historical relations and soft-delete targets through `deletedAt`. Add indexes for due targets, newest checks per target, open incidents, current status, and heartbeat lookup.

Generate the Prisma client and implement database reset only when `NODE_ENV === "test"` and the database name is exactly `monitoring_system_test`; otherwise throw before destructive SQL. Keep availability and content-validation counters separate as documented in the approved specification.

- [ ] **Step 4: Verify the focused pass**

Run: `pnpm --filter @monitoring/database prisma:migrate:test && pnpm --filter @monitoring/database test -- schema.integration.test.ts`

Expected: migration applies to the test database and every schema assertion passes.

- [ ] **Step 5: Run the affected integration check**

Run: `pnpm --filter @monitoring/database typecheck && pnpm --filter @monitoring/database prisma:validate`

Expected: both commands exit zero.

- [ ] **Step 6: Commit the passing deliverable**

```bash
git add packages/database
git commit -m "feat: add monitoring persistence schema"
```

### Task 3: Pure status policy and incident transitions

**Files:**
- Create: `packages/monitoring/package.json`
- Create: `packages/monitoring/tsconfig.json`
- Create: `packages/monitoring/src/types.ts`
- Create: `packages/monitoring/src/status-policy.ts`
- Create: `packages/monitoring/src/status-policy.test.ts`
- Create: `packages/monitoring/src/staleness.ts`
- Create: `packages/monitoring/src/staleness.test.ts`
- Create: `packages/monitoring/src/index.ts`

**Interfaces:**
- Consumes: `ApplyCheckResultInput { targetState, result, openIncidents, now }` and `DeriveStatusInput { persistedStatus, lastCheckedAt, intervalSeconds, collectorFresh, maintenanceMode, now }`.
- Produces: `applyCheckResult(input): MonitoringTransition` and `deriveDisplayedStatus(input): MonitoringStatus`.

```ts
type MonitoringStatus =
  | "UNKNOWN" | "ONLINE" | "WARNING" | "OFFLINE"
  | "ERROR" | "STALE" | "MAINTENANCE";

type MonitoringTransition = {
  nextStatus: MonitoringStatus;
  nextConsecutiveFailures: number;
  nextConsecutiveContentFailures: number;
  incidentActions: Array<
    | { action: "OPEN"; kind: "OFFLINE" | "CONTENT_ERROR" | "BROWSER_ERROR" }
    | { action: "TOUCH"; incidentId: string }
    | { action: "CLOSE"; incidentId: string }
  >;
};
```

- [ ] **Step 1: Add focused failing policy tests**

Add table-driven tests for every approved transition:

- UNKNOWN → ONLINE only after successful required validation.
- First and second availability failures → WARNING.
- Third consecutive availability failure → OFFLINE and one OPEN action.
- Additional failure → TOUCH, not a duplicate OPEN.
- Successful recovery → ONLINE and CLOSE.
- Slow success → WARNING without incrementing availability failures.
- First keyword mismatch → WARNING; third → ERROR/CONTENT_ERROR.
- Browser selector failure → ERROR/BROWSER_ERROR, never OFFLINE.
- Maintenance precedence and STALE precedence.
- STALE when `lastCheckedAt` is older than twice the interval or collector heartbeat is stale.

- [ ] **Step 2: Verify the relevant failure**

Run: `pnpm --filter @monitoring/core test -- status-policy.test.ts staleness.test.ts`

Expected: non-zero exit because the policy functions are missing.

- [ ] **Step 3: Implement the minimum pure policy**

Implement deterministic functions without database, clock, queue, HTTP, or framework imports. Encode status precedence exactly as `MAINTENANCE > STALE > OFFLINE > ERROR > WARNING > ONLINE > UNKNOWN`. Require callers to provide `now`; never read the system clock internally.

- [ ] **Step 4: Verify the focused pass**

Run: `pnpm --filter @monitoring/core test -- status-policy.test.ts staleness.test.ts`

Expected: all transition and precedence cases pass.

- [ ] **Step 5: Run the affected integration check**

Run: `pnpm --filter @monitoring/core test && pnpm --filter @monitoring/core typecheck`

Expected: full package tests and types pass.

- [ ] **Step 6: Commit the passing deliverable**

```bash
git add packages/monitoring
git commit -m "feat: define monitoring status policy"
```

### Task 4: SSRF-safe HTTP, keyword, DNS, redirect, latency, and SSL checker

**Files:**
- Create: `apps/collector/package.json`
- Create: `apps/collector/tsconfig.json`
- Create: `apps/collector/src/http/address-policy.ts`
- Create: `apps/collector/src/http/address-policy.test.ts`
- Create: `apps/collector/src/http/safe-fetch.ts`
- Create: `apps/collector/src/http/safe-fetch.integration.test.ts`
- Create: `apps/collector/src/http/http-checker.ts`
- Create: `apps/collector/src/http/http-checker.test.ts`
- Create: `apps/collector/src/http/ssl-inspector.ts`
- Create: `apps/collector/src/http/ssl-inspector.test.ts`
- Create: `apps/collector/src/test/http-fixture-server.ts`
- Create: `apps/collector/src/index.ts`

**Interfaces:**
- Consumes: `HttpCheckTarget { targetId, url, timeoutMs, acceptedStatusCodes, expectedKeyword, slowThresholdMs }` and injected DNS/connect/clock dependencies.
- Produces: `runHttpCheck(target, deps): Promise<NormalizedCheckResult>` with outcome, timings, final URL, redirects, sanitized resolved addresses, keyword result, SSL expiry, and categorized error.

- [ ] **Step 1: Add the focused failing safety and checker tests**

Test address rejection for loopback, RFC1918/private, link-local, multicast, unspecified, IPv4-mapped IPv6, IPv6 loopback/private/link-local, and common metadata addresses. Test public addresses are allowed. Integration fixtures assert:

The local HTTP fixtures use an injected resolver and transport that map an allowed documentation-range address to the loopback fixture server. Production address validation is never disabled or weakened for tests.

- Final 200 and matching keyword → SUCCESS.
- 200 and missing keyword → VALIDATION_FAILURE/CONTENT.
- Configured accepted redirect ending in 200 → SUCCESS with redirect count.
- More than five redirects → FAILURE/REDIRECT.
- Redirect to a blocked destination is rejected before the second connection.
- DNS answer changes to a blocked address before connection → rejected.
- Timeout → FAILURE/TIMEOUT.
- 500 outside accepted range → FAILURE/HTTP_STATUS.
- Oversized body is truncated for validation and never logged.
- Slow success records duration but remains a successful fact for policy evaluation.

- [ ] **Step 2: Verify the relevant failure**

Run: `pnpm --filter @monitoring/collector test -- address-policy.test.ts safe-fetch.integration.test.ts http-checker.test.ts ssl-inspector.test.ts`

Expected: non-zero exit because checker modules are missing.

- [ ] **Step 3: Implement the minimum safe checker**

Use explicit DNS resolution and validated connection targets. Revalidate each redirect, strip sensitive cross-origin headers, cap redirects at five, cap validation body bytes, enforce total/connect timeouts, and sanitize all error strings. Inspect certificate expiry without disabling TLS verification. Return facts only; do not write database state or determine the final displayed status here.

- [ ] **Step 4: Verify the focused pass**

Run the identical focused command.

Expected: every safety, timeout, redirect, content, HTTP status, and SSL case passes.

- [ ] **Step 5: Run the affected integration check**

Run: `pnpm --filter @monitoring/collector test && pnpm --filter @monitoring/collector typecheck`

Expected: collector package tests and types pass without real internet access.

- [ ] **Step 6: Commit the passing deliverable**

```bash
git add apps/collector
git commit -m "feat: add safe HTTP monitoring checks"
```

### Task 5: Result persistence, incidents, `pg-boss` scheduler, and HTTP worker

**Files:**
- Create: `packages/monitoring/src/persist-result.ts`
- Create: `packages/monitoring/src/persist-result.integration.test.ts`
- Create: `packages/shared/src/queues.ts`
- Create: `packages/shared/src/events.ts`
- Create: `apps/scheduler/package.json`
- Create: `apps/scheduler/tsconfig.json`
- Create: `apps/scheduler/src/dispatch-due-targets.ts`
- Create: `apps/scheduler/src/dispatch-due-targets.integration.test.ts`
- Create: `apps/scheduler/src/heartbeat.ts`
- Create: `apps/scheduler/src/main.ts`
- Create: `apps/collector/src/http-worker.ts`
- Create: `apps/collector/src/http-worker.integration.test.ts`
- Create: `apps/collector/src/heartbeat.ts`
- Modify: `apps/collector/src/index.ts`

**Interfaces:**
- Consumes: queue `monitor:http` jobs `{ jobVersion: 1, targetId, trigger: "SCHEDULED" | "MANUAL", scheduledFor }`; `NormalizedCheckResult`.
- Produces: `persistCheckResult(input): Promise<PersistedTransition>`; commit-ordered PostgreSQL `monitoring_events` notifications; scheduler and collector heartbeats.

- [ ] **Step 1: Add focused failing persistence and scheduling tests**

Test that persistence runs in one transaction and:

- Inserts the immutable check.
- Applies the pure status policy.
- Updates target counters/timestamps.
- Opens, touches, or closes exactly one incident.
- Calls `pg_notify` with a sanitized payload inside the result transaction, so delivery occurs only after commit and nothing is delivered after rollback.

Test scheduler behavior:

- Selects only enabled, non-deleted due targets.
- Enqueues unique jobs and atomically advances due time.
- Does not enqueue when a target's unique job is active/queued.
- Staggers initial due times.
- Writes heartbeat independently of target jobs.

- [ ] **Step 2: Verify the relevant failure**

Run: `pnpm --filter @monitoring/core test -- persist-result.integration.test.ts && pnpm --filter @monitoring/scheduler test -- dispatch-due-targets.integration.test.ts && pnpm --filter @monitoring/collector test -- http-worker.integration.test.ts`

Expected: non-zero exit because persistence, queue contracts, scheduler, and worker are absent.

- [ ] **Step 3: Implement the minimum queue pipeline**

Define queue/event schemas in shared code with Zod validation and `jobVersion: 1`. Implement transaction-safe result persistence, in-transaction `pg_notify`, scheduler polling, `pg-boss` singleton keys `http:<targetId>`, configurable concurrency, bounded retries for internal infrastructure failures only, and heartbeats. Use `FOR UPDATE SKIP LOCKED` and the queue's PostgreSQL adapter on the same connection/transaction so due-time advancement and enqueue commit together. Monitoring failures such as timeout/500 are successful job executions containing failed check results and are not retried by `pg-boss`.

- [ ] **Step 4: Verify the focused pass**

Run the identical focused commands.

Expected: persistence, uniqueness, incident, publication-order, heartbeat, and worker cases pass.

- [ ] **Step 5: Run the affected integration check**

Run: `pnpm --filter @monitoring/core test && pnpm --filter @monitoring/scheduler test && pnpm --filter @monitoring/collector test`

Expected: all affected packages pass against test PostgreSQL, including the `pg-boss` schema.

- [ ] **Step 6: Commit the passing deliverable**

```bash
git add packages/monitoring packages/shared apps/scheduler apps/collector
git commit -m "feat: schedule and persist HTTP monitoring"
```

### Task 6: Express API, server-side sessions, roles, target CRUD, history, and Check Now

**Files:**
- Create: `apps/api/package.json`
- Create: `apps/api/tsconfig.json`
- Create: `apps/api/src/app.ts`
- Create: `apps/api/src/server.ts`
- Create: `apps/api/src/auth/password.ts`
- Create: `apps/api/src/auth/session-service.ts`
- Create: `apps/api/src/auth/middleware.ts`
- Create: `apps/api/src/auth/csrf.ts`
- Create: `apps/api/src/auth/auth.integration.test.ts`
- Create: `apps/api/src/commands/create-admin.ts`
- Create: `apps/api/src/routes/auth.ts`
- Create: `apps/api/src/routes/targets.ts`
- Create: `apps/api/src/routes/targets.integration.test.ts`
- Create: `apps/api/src/routes/dashboard.ts`
- Create: `apps/api/src/routes/history.ts`
- Create: `apps/api/src/routes/history.integration.test.ts`
- Create: `apps/api/src/routes/collectors.ts`
- Create: `apps/api/src/http/problem-details.ts`

**Interfaces:**
- Consumes: Prisma models, queue `monitor:http`, `deriveDisplayedStatus`, and validated request schemas.
- Produces: approved `/api/auth/*`, `/api/targets*`, `/api/dashboard/summary`, `/api/checks`, `/api/incidents`, and `/api/collectors/status` JSON contracts.

- [ ] **Step 1: Add focused failing API tests**

Assert:

- Login succeeds with valid credentials and sets an HTTP-only cookie; invalid credentials return 401 without identifying whether the email exists.
- Repeated invalid logins are rate-limited.
- Logout revokes the server-side session.
- Deactivated users and revoked/expired sessions are rejected.
- Mutations reject a missing or invalid session-bound CSRF header and an unapproved browser Origin.
- VIEWER can read but receives 403 for every mutation.
- ADMIN creates a target as UNKNOWN, updates it, soft-deletes it, toggles maintenance, and enqueues Check Now.
- Unsafe URLs receive 422 without revealing resolved internal address details.
- Check Now returns 202 and never invokes the checker inline.
- Lists are paginated and newest-first.
- Dashboard derives STALE at read time.

- [ ] **Step 2: Verify the relevant failure**

Run: `pnpm --filter @monitoring/api test -- auth.integration.test.ts targets.integration.test.ts history.integration.test.ts`

Expected: non-zero exit because the API package is missing.

- [ ] **Step 3: Implement the minimum API**

Create an Express app factory separate from the listening server. Use Argon2id password hashes plus random opaque session and CSRF tokens; persist only their hashes. Configure the cookie as HTTP-only, Secure in production, SameSite=Lax, and path `/`. Allow credentialed browser requests only from the configured web origin, require the session-bound CSRF header for mutations, and rate-limit login attempts. Add Zod request/response validation, role middleware, stable problem-details errors, soft deletion, pagination, and Check Now queueing with manual job IDs that cannot overlap the same target's active HTTP job. Target creation rejects non-HTTP(S) schemes and literal internal hosts; the collector remains responsible for complete DNS and redirect-time destination validation.

Implement the command demonstrated by `pnpm --filter @monitoring/api admin:create --email admin@example.test --name "Monitoring Admin"` with a hidden password prompt; at execution time the operator supplies the real email and name. Reject weak or empty input without echoing it or logging secrets.

- [ ] **Step 4: Verify the focused pass**

Run the identical focused command.

Expected: all authentication, authorization, CRUD, safety, history, dashboard, and Check Now tests pass.

- [ ] **Step 5: Run the affected integration check**

Run: `pnpm --filter @monitoring/api test && pnpm --filter @monitoring/api typecheck`

Expected: full API suite and typechecking pass.

- [ ] **Step 6: Commit the passing deliverable**

```bash
git add apps/api
git commit -m "feat: expose secured monitoring API"
```

### Task 7: Post-commit real-time event delivery and reconnect reconciliation

**Files:**
- Create: `apps/api/src/realtime/socket-server.ts`
- Create: `apps/api/src/realtime/event-subscriber.ts`
- Create: `apps/api/src/realtime/realtime.integration.test.ts`
- Modify: `apps/api/src/server.ts`
- Modify: `apps/api/src/app.ts`
- Modify: `packages/shared/src/events.ts`

**Interfaces:**
- Consumes: PostgreSQL `monitoring_events` notifications validated as `MonitoringEvent` and authenticated session cookies during Socket.IO handshake.
- Produces: Socket.IO events `monitoring:check-completed`, `monitoring:status-updated`, `monitoring:incident-opened`, `monitoring:incident-closed`, and `monitoring:collector-status`.

- [ ] **Step 1: Add the focused failing real-time tests**

Assert unauthenticated socket connections are rejected; authenticated clients receive a sanitized event after a committed result; secret/raw fields are absent; malformed PostgreSQL notifications are logged and dropped; reconnecting clients use REST readback to obtain the current state even when an event was missed.

- [ ] **Step 2: Verify the relevant failure**

Run: `pnpm --filter @monitoring/api test -- realtime.integration.test.ts`

Expected: non-zero exit because Socket.IO authentication and PostgreSQL notification subscription are absent.

- [ ] **Step 3: Implement the minimum real-time bridge**

Attach Socket.IO to the API HTTP server. Authenticate the handshake through the existing hashed session flow. Hold a dedicated PostgreSQL `LISTEN monitoring_events` connection and validate/sanitize every notification before emitting. Reconnect and re-subscribe after connection loss. Use rooms only for authenticated application users in the MVP; do not expose worker/control channels to browsers. Preserve REST as the authoritative reconnect path.

- [ ] **Step 4: Verify the focused pass**

Run the identical focused command.

Expected: authentication, delivery, sanitization, malformed-message, and reconnect cases pass.

- [ ] **Step 5: Run the affected integration check**

Run: `pnpm --filter @monitoring/api test`

Expected: API and real-time tests all pass.

- [ ] **Step 6: Commit the passing deliverable**

```bash
git add apps/api packages/shared/src/events.ts
git commit -m "feat: stream monitoring status events"
```

### Task 8: Next.js dashboard, target management, history, and live cache updates

**Files:**
- Create: `apps/web/package.json`
- Create: `apps/web/tsconfig.json`
- Create: `apps/web/next.config.ts`
- Create: `apps/web/postcss.config.js`
- Create: `apps/web/tailwind.config.ts`
- Create: `apps/web/src/app/layout.tsx`
- Create: `apps/web/src/app/globals.css`
- Create: `apps/web/src/middleware.ts`
- Create: `apps/web/src/app/login/page.tsx`
- Create: `apps/web/src/app/dashboard/page.tsx`
- Create: `apps/web/src/app/targets/page.tsx`
- Create: `apps/web/src/app/targets/new/page.tsx`
- Create: `apps/web/src/app/targets/[id]/page.tsx`
- Create: `apps/web/src/app/incidents/page.tsx`
- Create: `apps/web/src/components/monitoring/status-badge.tsx`
- Create: `apps/web/src/components/monitoring/summary-cards.tsx`
- Create: `apps/web/src/components/monitoring/target-table.tsx`
- Create: `apps/web/src/components/monitoring/target-form.tsx`
- Create: `apps/web/src/lib/api-client.ts`
- Create: `apps/web/src/lib/socket-client.ts`
- Create: `apps/web/src/lib/query-provider.tsx`
- Create: `apps/web/src/__tests__/dashboard-live-update.test.tsx`
- Create: `apps/web/src/__tests__/target-form.test.tsx`
- Create: `apps/web/src/__tests__/permissions.test.tsx`

**Interfaces:**
- Consumes: REST API contracts and authenticated Socket.IO monitoring events.
- Produces: login, summary dashboard, target list/form/detail, incident list, live cache updates, and role-appropriate controls.

- [ ] **Step 1: Add focused failing component tests**

Assert:

- Dashboard renders all approved status totals and collector freshness.
- A `monitoring:status-updated` event updates the matching target and summary without page refresh.
- Reconnect invalidates/refetches dashboard and target queries.
- New target form sends the approved fields and presents 422 URL errors safely.
- VIEWER never sees mutation controls; ADMIN does.
- Status badges cover UNKNOWN, ONLINE, WARNING, OFFLINE, ERROR, STALE, and MAINTENANCE accessibly with text in addition to color.

- [ ] **Step 2: Verify the relevant failure**

Run: `pnpm --filter @monitoring/web test -- dashboard-live-update.test.tsx target-form.test.tsx permissions.test.tsx`

Expected: non-zero exit because the web package and components are missing.

- [ ] **Step 3: Implement the minimum user interface**

Scaffold Next.js App Router with Tailwind and TanStack Query. Add an authenticated layout, responsive dashboard, paginated/filterable target table, target form/detail/history, incidents, collector health, and Check Now/maintenance actions. Use credentials-included API requests, retrieve the session-bound CSRF token, and attach it to every mutation. Update query caches from Socket.IO and refetch on reconnect. Follow the supplied screenshot direction only as general dark-dashboard inspiration; do not copy CCTV-specific branding/data or modify Aptika UI.

- [ ] **Step 4: Verify the focused pass**

Run the identical focused command.

Expected: live-update, form, permission, and accessibility assertions pass.

- [ ] **Step 5: Run the affected integration check**

Run: `pnpm --filter @monitoring/web test && pnpm --filter @monitoring/web typecheck && pnpm --filter @monitoring/web build`

Expected: tests, typechecking, and production build pass.

- [ ] **Step 6: Commit the passing deliverable**

```bash
git add apps/web
git commit -m "feat: add live monitoring dashboard"
```

### Task 9: Playwright login-page validation and failure screenshots

**Files:**
- Create: `apps/collector/src/browser/browser-checker.ts`
- Create: `apps/collector/src/browser/browser-checker.integration.test.ts`
- Create: `apps/collector/src/browser/screenshot-store.ts`
- Create: `apps/collector/src/browser/screenshot-store.integration.test.ts`
- Create: `apps/collector/src/browser-worker.ts`
- Create: `apps/collector/src/browser-worker.integration.test.ts`
- Create: `apps/collector/src/test/browser-fixtures/login-page.html`
- Create: `apps/collector/src/test/browser-fixtures/missing-selector.html`
- Modify: `apps/api/src/routes/history.ts`
- Modify: `apps/api/src/routes/history.integration.test.ts`
- Modify: `apps/collector/src/index.ts`
- Modify: `packages/shared/src/queues.ts`
- Modify: `packages/monitoring/src/persist-result.ts`

**Interfaces:**
- Consumes: queue `monitor:browser` jobs `{ jobVersion: 1, targetId, trigger, scheduledFor }`; target browser scenario with public start URL and expected selector.
- Produces: `runBrowserCheck(scenario, deps): Promise<NormalizedCheckResult>`; private local screenshot file on failure; BROWSER check persistence and `BROWSER_ERROR` incidents.

- [ ] **Step 1: Add focused failing browser tests**

Assert:

- Page with configured selector → SUCCESS and no screenshot.
- Missing selector → VALIDATION_FAILURE/BROWSER and one screenshot key.
- Navigation timeout → FAILURE/BROWSER with screenshot attempt.
- Browser context is new per job and storage/cookies do not cross jobs.
- CAPTCHA/OTP fields are not filled, clicked, or bypassed.
- Screenshot file stays beneath the configured private root and uses a non-guessable opaque key without target credentials/query secrets.
- An authenticated user can stream a screenshot for an authorized check; missing, invalid, traversal, symlink-escape, or unauthorized requests do not reveal the key or filesystem path.
- Browser failure sets ERROR/BROWSER_ERROR but never OFFLINE.

- [ ] **Step 2: Verify the relevant failure**

Run: `pnpm --filter @monitoring/collector test -- browser-checker.integration.test.ts screenshot-store.integration.test.ts browser-worker.integration.test.ts && pnpm --filter @monitoring/api test -- history.integration.test.ts`

Expected: non-zero exit because browser modules and queue worker are absent.

- [ ] **Step 3: Implement the minimum browser worker**

Launch Chromium once per worker process and create isolated contexts per job. Enforce safe destination checks on navigation/redirects, JavaScript-enabled rendering, configured timeout, expected-selector assertion, and failure-only screenshots. Browser fixtures use an injected navigation/transport boundary to reach the local test server without disabling the production destination policy. Write through a filesystem adapter that generates an opaque key, verifies the resolved destination remains beneath the configured screenshot root, avoids following symlinks, and persists only the key. Add the authorized API endpoint that resolves the stored key and streams the image without exposing a path. Never add credential/login steps to the MVP scenario model.

- [ ] **Step 4: Verify the focused pass**

Run the identical focused command.

Expected: selector, isolation, timeout, no-CAPTCHA-action, screenshot, status, and authorized signed-URL cases pass.

- [ ] **Step 5: Run the affected integration check**

Run: `pnpm --filter @monitoring/collector test && pnpm --filter @monitoring/collector typecheck && pnpm --filter @monitoring/api test`

Expected: HTTP and browser collector suites plus the API history suite pass.

- [ ] **Step 6: Commit the passing deliverable**

```bash
git add apps/collector apps/api/src/routes/history.ts apps/api/src/routes/history.integration.test.ts packages/shared/src/queues.ts packages/monitoring/src/persist-result.ts
git commit -m "feat: add browser page monitoring"
```

### Task 10: End-to-end, 100-target capacity, retention, and operator runbook

**Files:**
- Create: `tests/e2e/playwright.config.ts`
- Create: `tests/e2e/monitoring-flow.spec.ts`
- Create: `tests/capacity/mock-target-server.ts`
- Create: `tests/capacity/run-100-targets.ts`
- Create: `tests/capacity/capacity-assertions.test.ts`
- Create: `apps/scheduler/src/retention.ts`
- Create: `apps/scheduler/src/retention.integration.test.ts`
- Create: `docs/runbooks/local-development.md`
- Create: `docs/runbooks/operations.md`
- Create: `docs/runbooks/security.md`
- Modify: `package.json`
- Modify: `.env.example`

**Interfaces:**
- Consumes: the complete local API, web, scheduler, collector, native PostgreSQL, and private screenshot filesystem.
- Produces: `pnpm e2e`, `pnpm capacity:test`, retention jobs, and reproducible local/operator instructions.

- [ ] **Step 1: Add failing system and capacity tests**

E2E test:

- Login as admin.
- Create a healthy target and observe UNKNOWN.
- Run Check Now and observe ONLINE without manual refresh.
- Switch fixture to fail three checks and observe WARNING then OFFLINE with one incident.
- Restore fixture and observe ONLINE with the same incident closed.
- Verify viewer cannot mutate.
- Verify maintenance suppresses alarm display.

Capacity assertions for 100 targets:

- Representative distribution: 70 healthy endpoints responding within 200 ms, 15 slow endpoints responding in 2 seconds, 10 endpoints timing out at 5 seconds, and 5 endpoints returning HTTP 200 with invalid expected content. Ten of the healthy targets also have browser selector checks enabled.

- No overlapping active job per target.
- Healthy target cadence remains within the configured interval under the representative pilot distribution.
- Queue oldest-job age does not grow continuously after a bounded burst.
- One timeout cohort does not block healthy targets.
- API/dashboard remains responsive during the run.

Retention assertions delete raw checks older than 90 days and screenshot objects older than 30 days while preserving incidents.

- [ ] **Step 2: Verify the relevant failure**

Run: `pnpm e2e && pnpm capacity:test && pnpm --filter @monitoring/scheduler test -- retention.integration.test.ts`

Expected: non-zero exit because the end-to-end harness, capacity runner, and retention job are absent.

- [ ] **Step 3: Implement the minimum verification and runbooks**

Add deterministic local fixture targets with configurable healthy/slow/timeout/content/browser behavior. Implement capacity metrics and assertions without contacting real government websites. Add scheduled retention with bounded batches and idempotent object deletion. Document exact local startup, migration, admin creation, process commands, health checks, backup expectations, secret handling, worker restart, stale diagnosis, and safe shutdown. Explicitly state that production deployment and Aptika integration are not performed.

- [ ] **Step 4: Verify the focused pass**

Run the identical focused command.

Expected: E2E state transitions, 100-target assertions, and retention tests pass.

- [ ] **Step 5: Run the complete release check**

Run: `pnpm lint && pnpm typecheck && pnpm test && pnpm build && pnpm e2e && pnpm capacity:test`

Expected: every command exits zero with no hidden test failures; capacity output records cycle latency, queue depth, CPU, memory, and worker utilization for pilot review.

- [ ] **Step 6: Commit the passing deliverable**

```bash
git add tests apps/scheduler docs/runbooks package.json .env.example
git commit -m "test: verify monitoring MVP at 100 targets"
```

## Open Product Decisions

No blocking product decisions remain for local MVP implementation. The following are explicitly deferred and must not be silently added:

- Production hosting and deployment topology.
- Public monitoring-system domain.
- Aptika Tools navigation or data integration.
- Email/Telegram notification rules and recipients.
- Excel/report export format.
- Approved accounts and mechanisms for authenticated CAPTCHA/OTP journeys.
- Production retention changes beyond 90-day raw checks and 30-day screenshots.

## Execution Boundary

Implementation stops after a verified local MVP and 100-target synthetic capacity report. It must not push to remote Git repositories, create cloud resources, deploy services, or change Aptika Tools without a new explicit user request.
