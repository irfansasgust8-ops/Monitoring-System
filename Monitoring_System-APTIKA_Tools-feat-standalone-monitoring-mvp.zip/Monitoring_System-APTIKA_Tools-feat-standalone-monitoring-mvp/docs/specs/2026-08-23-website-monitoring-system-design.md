# Website Monitoring System — Design Specification

Date: 2026-08-23
Status: Approved native-PostgreSQL revision, pending written review
Owner: Aptika monitoring project

## 1. Purpose

Build a standalone website and application monitoring system for approximately 100 targets. The system detects availability, degraded performance, content failures, browser-rendering failures, stale collectors, and maintenance periods. It does not use Uptime Kuma and does not modify or deploy the existing Aptika Tools frontend or backend.

The target inventory contains a balanced mix of public websites and applications with login pages. Some login flows use CAPTCHA and OTP. Because no official automation accounts or approved OTP/CAPTCHA automation mechanisms exist, the MVP verifies that login pages and required elements render but does not perform authenticated synthetic journeys.

## 2. Scope

### 2.1 MVP scope

- Independent administrator and viewer authentication.
- Target management with name, URL, organization/OPD, enabled state, intervals, timeouts, keywords, and monitoring methods.
- HTTP/HTTPS, redirect, DNS, SSL, keyword, response-time, and browser-rendering checks.
- Durable scheduled execution through PostgreSQL-backed `pg-boss` queues.
- Current status, append-only check history, and incident history.
- Real-time dashboard updates through Socket.IO.
- Failure screenshots for browser checks.
- Manual maintenance state and an administrator-only Check Now action.
- Collector heartbeat and derived STALE status.
- Security controls for credentials, authentication, logs, and outbound URL fetching.

### 2.2 Explicitly out of scope

- Any change to or deployment of existing Aptika Tools repositories.
- Embedding the monitoring dashboard inside Aptika Tools.
- Automated CAPTCHA bypass, OTP interception, or login without an approved monitoring account and mechanism.
- Telegram/email notifications.
- Excel export.
- Production deployment.
- Source-code exception monitoring inside target applications.
- AI-based bug diagnosis.

## 3. System boundary

The monitoring system is a standalone monorepo rooted at `D:\App\APTIKA\monitoring_system`. It is a sibling of the existing Aptika Tools frontend and backend, not a module inside either repository. Existing Aptika Tools source and Railway deployment remain read-only and outside this system boundary.

```text
D:\App\APTIKA\monitoring_system\
├── apps/
│   ├── web/          Next.js dashboard
│   ├── api/          Express REST API and Socket.IO server
│   ├── scheduler/    Due-target scheduling and queue dispatch
│   └── collector/    HTTP and Playwright workers
├── packages/
│   ├── database/     Prisma schema and PostgreSQL client
│   ├── monitoring/   Status policy and result processing
│   └── shared/       Shared schemas, types, and constants
├── scripts/             PowerShell setup and local process commands
├── storage/
│   └── screenshots/     Private failure screenshots; never web-public
├── tests/
└── docs/
```

### 3.1 Responsibilities

#### Web application

- Presents login, dashboard summary, target list, target detail, check history, incident history, configuration forms, and maintenance controls.
- Reads and mutates data only through the REST API.
- Subscribes to Socket.IO status events and updates cached dashboard data without page refresh.
- Never receives monitoring credentials or collector secrets.

#### API

- Owns user authentication, authorization, validation, target configuration, history queries, incident queries, and Check Now authorization.
- Calculates displayed STALE state from the latest successful collector/check timestamps.
- Broadcasts persisted status transitions and check summaries through Socket.IO.
- Does not run external probes inside HTTP request handlers.

#### Scheduler

- Selects enabled targets whose next HTTP or browser check is due.
- Dispatches unique queue jobs and advances the target's next due time atomically.
- Staggers target execution to prevent synchronized traffic spikes.
- Does not perform network or browser work itself.

#### Collector

- Consumes HTTP and browser jobs from separate queues.
- Applies timeouts, redirect limits, safe destination validation, and concurrency limits.
- Produces normalized facts; it does not independently invent UI status labels.
- Persists results through the shared monitoring result service so scheduled and Check Now executions use identical behavior.

#### Monitoring policy package

- Converts normalized check results plus prior target state into current state, counters, and incident transitions.
- Remains independent of HTTP, browser, database, and web framework details.
- Exposes deterministic functions suitable for focused unit tests.

## 4. Technology choices

- Frontend: Next.js, TypeScript, and Tailwind CSS.
- API: Node.js, Express, TypeScript, and Socket.IO.
- Persistence: PostgreSQL through Prisma.
- Queue and scheduling coordination: `pg-boss` using the same PostgreSQL server in its own managed schema.
- Browser automation: Playwright using Chromium.
- Screenshot storage: a private local filesystem adapter rooted at `storage/screenshots`; the interface may later be replaced by S3 storage without changing collector behavior.
- HTTP client: a Node.js client supporting strict timeouts, redirect inspection, and response metadata.
- Development runtime: the existing native PostgreSQL 18 Windows service. API, web, scheduler, and collector processes run independently through PowerShell/pnpm commands.
- Dependency versions are pinned by lockfiles when scaffolding occurs.

## 5. Data model

### 5.1 `users`

- `id`
- `name`
- `email` (unique)
- `password_hash`
- `role`: `ADMIN` or `VIEWER`
- `is_active`
- `created_at`, `updated_at`

Only administrators may create, edit, disable, delete, maintain, or manually check targets. Viewers have read-only dashboard and history access.

### 5.2 `monitoring_targets`

- `id`
- `name`
- `url`
- `opd_name` (optional display grouping)
- `enabled`
- `maintenance_mode`
- `http_enabled`
- `browser_enabled`
- `http_interval_seconds` (default 30)
- `browser_interval_seconds` (default 600)
- `timeout_seconds` (default 8)
- `accepted_status_codes` (default range 200–399)
- `expected_keyword` (optional)
- `expected_selector` (optional browser assertion)
- `slow_threshold_ms` (default 5000)
- `current_status`
- `consecutive_failures`
- `consecutive_content_failures`
- `last_checked_at`
- `last_success_at`
- `next_http_check_at`
- `next_browser_check_at`
- `created_at`, `updated_at`
- `deleted_at` (nullable soft-delete timestamp)

New targets begin as `UNKNOWN`; they are never marked ONLINE before a successful check.
Availability and content-validation failure counters are stored separately so one class of failure cannot erase or inflate the other.

### 5.3 `user_sessions`

- `id`
- `user_id`
- `token_hash`
- `csrf_token_hash`
- `expires_at`
- `last_seen_at`
- `revoked_at` (nullable)
- `created_at`

The browser receives only an opaque session token in a secure cookie. The database stores only its hash. Logout and account deactivation revoke server-side sessions.

### 5.4 `monitoring_checks`

- `id`
- `target_id`
- `check_type`: `HTTP` or `BROWSER`
- `started_at`, `finished_at`
- `outcome`: `SUCCESS`, `FAILURE`, or `VALIDATION_FAILURE`
- `http_status` (nullable)
- `response_time_ms` (nullable)
- `final_url` (nullable)
- `redirect_count` (nullable)
- `resolved_addresses` (sanitized array)
- `keyword_matched` (nullable)
- `selector_matched` (nullable)
- `ssl_expires_at` (nullable)
- `error_category` (nullable)
- `error_message` (sanitized and nullable)
- `screenshot_key` (nullable)
- `created_at`

Raw checks are retained for 90 days. Incident records remain available indefinitely. Screenshot files are retained for 30 days. `screenshot_key` is an opaque generated identifier, never an absolute path or user-supplied filename.

### 5.5 `monitoring_incidents`

- `id`
- `target_id`
- `kind`: `OFFLINE`, `CONTENT_ERROR`, or `BROWSER_ERROR`
- `opened_at`
- `closed_at` (nullable while open)
- `opening_check_id`
- `closing_check_id` (nullable)
- `last_observed_at`
- `created_at`, `updated_at`

There may be at most one open incident of each kind per target. A repeated failure updates the existing incident instead of opening duplicates.

### 5.6 `collector_heartbeats`

- `collector_id`
- `collector_type`: `HTTP`, `BROWSER`, or `SCHEDULER`
- `last_seen_at`
- `version`
- `metadata` containing non-secret operational counters

### 5.7 `browser_scenarios`

- `id`
- `target_id`
- `start_url`
- `expected_selector`
- `wait_strategy`
- `enabled`
- `created_at`, `updated_at`

The MVP supports unauthenticated page-render scenarios only. Credential fields are deliberately absent until an approved account and OTP/CAPTCHA mechanism exists.

### 5.8 Queue schema

`pg-boss` owns its queue tables in a dedicated PostgreSQL schema. Application migrations do not edit those internal tables. Queue payloads contain only a version, target ID, trigger, and scheduled time; target URLs and configuration are read from application tables when a worker starts.

## 6. Check scheduling and concurrency

### 6.1 HTTP checks

- Default interval: 30 seconds.
- Default timeout: 8 seconds.
- Initial worker concurrency: 10, configurable through environment settings.
- Jobs are staggered across the interval.
- Only one active HTTP job per target is allowed.
- A new job is not enqueued while the prior job remains active.

### 6.2 Browser checks

- Default interval: 10 minutes.
- Initial worker concurrency: 2.
- One reusable browser process may create isolated contexts; cookies and storage are never shared between targets.
- A browser job captures a screenshot only on failure.
- Only one active browser job per target is allowed.

### 6.3 Backpressure

- `pg-boss` singleton queue keys prevent duplicate active jobs for the same target and check type.
- The scheduler locks due target rows with `FOR UPDATE SKIP LOCKED` and uses the `pg-boss` PostgreSQL adapter on the same transaction/connection so enqueueing and due-time advancement commit or roll back together.
- Queue depth, oldest job age, active worker count, and timeout count are exposed as operational metrics.
- When the queue cannot keep up, jobs remain queued and the API derives STALE rather than claiming a target is ONLINE.
- The 100-target load test determines final production concurrency and intervals; defaults remain unchanged until evidence supports adjustment.

## 7. Safe outbound requests

Before every initial request and redirect:

- Allow only `http` and `https` schemes.
- Reject embedded credentials and malformed hostnames.
- Resolve all destination addresses.
- Reject loopback, private, link-local, multicast, unspecified, and cloud-metadata destinations for IPv4 and IPv6.
- Connect only after validation and verify that the connected destination remains allowed.
- Re-resolve and revalidate every redirect to address DNS rebinding and redirect-based bypasses.
- Limit redirects to five.
- Limit response body bytes used for keyword validation.
- Never forward collector cookies, authorization headers, or internal headers across origins.

Administrators may not override these restrictions from the UI in the MVP.

## 8. Normalized results and status policy

### 8.1 Status values

- `UNKNOWN`: no completed check exists.
- `ONLINE`: the most recent required checks satisfy availability and validation rules.
- `WARNING`: one or two availability failures, slow response, approaching SSL expiry, or a non-repeated content validation failure.
- `OFFLINE`: three consecutive availability failures caused by DNS, connection, timeout, TLS, or final HTTP 5xx conditions.
- `ERROR`: repeated content validation failure or a failed browser element assertion while the server remains reachable.
- `STALE`: no current result exists within twice the configured interval, or required collectors/scheduler have stale heartbeats.
- `MAINTENANCE`: administrator-controlled state that suppresses new incident notifications and visual alarms while checks may continue for observation.

### 8.2 Status precedence

Displayed precedence is:

`MAINTENANCE` → `STALE` → `OFFLINE` → `ERROR` → `WARNING` → `ONLINE` → `UNKNOWN`.

### 8.3 Transition rules

- A successful HTTP check with acceptable latency and valid keyword sets the HTTP component ONLINE and resets availability failure count.
- A final HTTP status outside the target's accepted status configuration counts as an availability failure.
- Response time over the target threshold sets WARNING without counting as an availability failure.
- The first or second availability failure sets WARNING.
- The third consecutive availability failure sets OFFLINE and opens or updates an OFFLINE incident.
- A successful availability check after OFFLINE returns the availability component ONLINE and closes its incident.
- The first keyword mismatch sets WARNING; the third consecutive mismatch sets ERROR and opens a CONTENT_ERROR incident.
- A successful keyword validation closes the CONTENT_ERROR incident.
- A browser assertion failure sets ERROR and opens or updates a BROWSER_ERROR incident; it does not set OFFLINE.
- A successful browser assertion closes the BROWSER_ERROR incident.
- SSL expiry within 30 days sets WARNING; an expired certificate is treated as an availability failure when TLS validation prevents a successful request.
- STALE is derived at read time from timestamps and collector heartbeats, so a stopped collector cannot leave a falsely current ONLINE result.

## 9. API contract

All endpoints are prefixed with `/api`.

### 9.1 Authentication

- `POST /auth/login`
- `POST /auth/logout`
- `GET /auth/me`
- `GET /auth/csrf`

Authentication uses an HTTP-only, Secure, SameSite cookie. State-changing requests require a session-bound CSRF token in a request header, and credentialed browser requests are accepted only from the configured web origin. Login responses never expose password hashes or internal session identifiers.

### 9.2 Targets

- `GET /targets`
- `POST /targets` (ADMIN)
- `GET /targets/:id`
- `PUT /targets/:id` (ADMIN)
- `DELETE /targets/:id` (ADMIN)
- `POST /targets/:id/check-now` (ADMIN)
- `POST /targets/:id/maintenance` (ADMIN)

`check-now` enqueues the same job type used by the scheduler and returns `202 Accepted` with a public job reference. It never performs a probe during the API request.

Target deletion is a soft delete: scheduling stops immediately while historical checks and incidents remain queryable to administrators.

### 9.3 Dashboard and history

- `GET /dashboard/summary`
- `GET /checks`
- `GET /targets/:id/checks`
- `GET /checks/:id/screenshot`
- `GET /incidents`
- `GET /incidents/:id`
- `GET /collectors/status`

List endpoints support pagination and stable newest-first ordering. Dashboard status is derived using the precedence and STALE rules above. Screenshot files remain outside the web-public directory; the authorized screenshot endpoint validates the session and check access, accepts no path from the request, resolves only the stored opaque key beneath the configured screenshot root, rejects traversal/symlink escapes, and streams the image without exposing a filesystem path.

### 9.4 Real-time events

Socket.IO emits:

- `monitoring:check-completed`
- `monitoring:status-updated`
- `monitoring:incident-opened`
- `monitoring:incident-closed`
- `monitoring:collector-status`

Events contain public target/result summaries and never include secrets, raw HTML, cookies, headers, or internal addresses.

Collectors call `pg_notify` with a sanitized payload inside the same result transaction; PostgreSQL delivers the notification only after that transaction commits. The API holds a dedicated `LISTEN` connection and forwards validated events to authenticated Socket.IO clients. PostgreSQL notifications are an update signal rather than durable history: if the API is temporarily unavailable, persisted database state remains authoritative and clients reconcile through normal REST reads after reconnecting.

## 10. User interface

### 10.1 Dashboard

- Summary cards: total, online, warning, offline, error, stale, and maintenance.
- Latest update and collector-health indicators.
- Filters by status, method, and OPD.
- Search by target name or public URL.
- Recent open incidents.

### 10.2 Target list

- Name, URL, OPD, status, enabled state, response time, last check, and monitoring methods.
- Pagination, filters, stable sorting, and administrator actions.

### 10.3 Target detail

- Current status and component results.
- HTTP/SSL/browser configuration.
- Recent checks and incident timeline.
- Response-time history.
- Failure screenshot link when available and authorized.

### 10.4 Target form

- General configuration, HTTP interval/timeout, optional keyword, browser toggle, and expected selector.
- URL safety validation errors are shown without disclosing internal network details.

## 11. Error handling and observability

- Errors are categorized as DNS, CONNECT, TIMEOUT, TLS, HTTP_STATUS, REDIRECT, CONTENT, BROWSER, QUEUE, or INTERNAL.
- User-facing messages are concise; detailed structured logs remain server-side.
- Logs include correlation ID, target ID, check ID, duration, and category.
- Logs exclude response bodies, credentials, cookies, OTP, authorization headers, and sensitive query strings.
- API health, PostgreSQL health, `pg-boss` queue depth/oldest age, scheduler heartbeat, worker heartbeat, completed checks, and timeout rate are observable independently.
- API or Socket.IO outages do not discard queued checks; persisted results are replayed through normal dashboard reads when clients reconnect.

## 12. Testing strategy

### 12.1 Unit tests

- Status precedence and every state transition.
- Consecutive availability and keyword failure counters.
- Incident open/update/close behavior.
- STALE derivation.
- URL and resolved-address safety policy.
- Sanitization of errors and event payloads.

### 12.2 Integration tests

- Authentication and role authorization.
- Target CRUD and Check Now queueing.
- PostgreSQL persistence and unique open-incident constraints.
- `pg-boss` singleton-job uniqueness, retry, worker-crash recovery, and queue persistence behavior.
- HTTP fixtures for success, slow response, timeout, redirect loop, DNS failure, TLS failure, HTTP 500, and HTTP 200 with incorrect content.
- Socket.IO delivery after committed result persistence.

### 12.3 Browser and end-to-end tests

- Browser fixture with expected selector present.
- Browser fixture with missing selector and captured failure screenshot.
- Dashboard initial data load and live status update without refresh.
- Admin and viewer permissions.
- Maintenance and Check Now workflows.

### 12.4 Capacity test

- Simulate 100 targets with representative healthy, slow, and timeout distributions.
- Confirm jobs do not overlap per target.
- Confirm queue backlog does not grow continuously under the agreed pilot distribution.
- Measure cycle latency, CPU, memory, `pg-boss` queue depth/oldest age, PostgreSQL write rate, and browser-worker utilization.
- Use the results to change concurrency or intervals only after the MVP behavior remains green.

## 13. Acceptance criteria

- One hundred targets can be scheduled without overlapping jobs for the same target.
- Healthy targets are checked at their configured cadence under the pilot load profile.
- A single slow or timed-out target does not block unrelated targets.
- HTTP 200 with invalid required content is not reported ONLINE.
- Repeated availability failures transition WARNING to OFFLINE and create one incident.
- Recovery closes the corresponding incident deterministically.
- Browser element failure reports ERROR rather than OFFLINE.
- Stopped collectors or scheduler produce derived STALE status instead of leaving a falsely current ONLINE status.
- Dashboard state updates through Socket.IO without manual refresh and remains correct after reconnect/readback.
- Restarting API, scheduler, or collectors does not lose target configuration, queued work, persisted history, or incidents.
- ADMIN and VIEWER permissions are enforced.
- Unsafe destinations are rejected before any connection and after every redirect.
- Existing Aptika Tools source and deployment remain unchanged.

## 14. Delivery sequence

1. Relocate the standalone monorepo to `D:\App\APTIKA\monitoring_system`, configure native PostgreSQL, shared configuration, PowerShell scripts, and the test harness.
2. Database schema, authentication, roles, and target CRUD.
3. Pure monitoring policy and incident state machine using test-first development.
4. HTTP collector, safe fetch policy, scheduler, `pg-boss`, and Check Now.
5. Dashboard read APIs and Next.js target/dashboard screens.
6. Socket.IO events and live client cache updates.
7. Browser worker, expected-selector checks, and failure screenshots.
8. Capacity/security verification and pilot tuning for 100 targets.

Production deployment, Aptika integration, notification channels, exports, and authenticated CAPTCHA/OTP browser journeys require separate approved designs after the MVP is verified.

## 15. Native Windows operation

- PostgreSQL databases are named `monitoring_system` and `monitoring_system_test`.
- Destructive test reset code refuses to run unless `NODE_ENV=test` and the database name is exactly `monitoring_system_test`.
- A first-run PowerShell script accepts a privileged PostgreSQL connection through a hidden prompt or environment variable, creates/checks the databases and least-privilege application role without logging credentials, then applies migrations. Other scripts create the first administrator through a hidden password prompt, start each application process, report health, and stop local processes safely.
- Database credentials and the absolute screenshot root are loaded from `.env`; `.env` and screenshot contents are ignored by Git.
- API, web, scheduler, and collector remain separate processes even though they share one PostgreSQL server.
- Local startup documentation includes PostgreSQL service checks, backup expectations, stale-worker diagnosis, queue inspection, and recovery after a process restart.
